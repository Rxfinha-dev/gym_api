/* eslint-disable @typescript-eslint/no-explicit-any */
export function createControllerMiddleware(factory: () => any) {
  return (req: any, res: any, next: any) => {
    const controller = factory();
    controller.execute(req, res, next);
  };
}
