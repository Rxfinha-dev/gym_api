import jwt, { JwtPayload } from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';
import { AppDataSource } from '../config/typeorm.config';
import { EUserType } from '../modules/user/enums/EUserType.enum';
import { Users } from '../modules/user/models/User.model';

interface CustomJwtPayload extends JwtPayload {
  userId: string;
  companyId: string;
}

export const authenticateToken = (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Token não fornecido.' });
  }

  jwt.verify(
    token,
    process.env.JWT_SECRET || 'gym_tech_jwt_secret',
    (err, decoded) => {
      if (err) {
        return res.status(403).json({ message: 'Token inválido.' });
      }

      const payload = decoded as CustomJwtPayload;
      req.params.userId = payload.userId;
      req.params.companyId = payload.companyId;
      next();
    },
  );
};

export const checkPermission = (allowedTypes: EUserType[]) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    const { userId } = req.params;
    const userRepository = AppDataSource.getRepository(Users);

    try {
      const user = await userRepository.findOneBy({ id: userId });

      if (!user) {
        return res.status(404).json({ message: 'Usuário não encontrado.' });
      }

      if (!allowedTypes.includes(user.type)) {
        return res.status(403).json({
          message: 'Você não tem permissão para acessar o recurso desejado.',
        });
      }

      next();
    } catch (error) {
      next(error);
    }
  };
};
