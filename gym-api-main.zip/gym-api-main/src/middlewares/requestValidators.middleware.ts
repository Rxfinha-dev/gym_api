import { body, ValidationChain } from 'express-validator';
import { EUserType } from '../modules/user/enums/EUserType.enum';
import { ENotificationFrequency } from '../modules/notifications/enums/ENotifications.enum';

export const validateLogin: ValidationChain[] = [
  body('email').isEmail().withMessage('Insira um e-mail válido.'),
  body('password').notEmpty().withMessage('A senha deve ser informada.'),
];

export const validateRefreshToken: ValidationChain[] = [
  body('refreshToken')
    .notEmpty()
    .withMessage('Token de atualização não informado.'),
];

export const validateCreateUser: ValidationChain[] = [
  body('type')
    .optional()
    .isIn(Object.values(EUserType))
    .withMessage('Tipo de usuário inválido.'),
  body('name').isLength({ min: 1 }).withMessage('O nome é obrigatório.'),
  body('email').isEmail().withMessage('Insira um e-mail válido.'),
  body('password')
    .isString()
    .withMessage('A senha do usuário é obrigatória.')
    .isLength({ min: 8 })
    .withMessage('A senha deve ter pelo menos 8 caracteres.')
    .matches(/[a-zA-Z]/)
    .withMessage('A senha deve conter pelo menos uma letra.')
    .matches(/\d/)
    .withMessage('A senha deve conter pelo menos um número.')
    .notEmpty()
    .withMessage('A senha do usuário não pode estar vazia.'),
];

export const validateChangePassword: ValidationChain[] = [
  body('currentPassword')
    .isString()
    .withMessage('A senha atual é obrigatória.')
    .notEmpty()
    .withMessage('A senha atual não pode estar vazia.'),
  body('newPassword')
    .isString()
    .withMessage('A nova senha é obrigatória.')
    .isLength({ min: 8 })
    .withMessage('A nova senha deve ter pelo menos 8 caracteres.')
    .notEmpty()
    .withMessage('A nova senha não pode estar vazia.'),
];

export const validateCreatePlan: ValidationChain[] = [
  body('name').isLength({ min: 1 }).withMessage('O nome é obrigatório.'),
  body('price').isDecimal().withMessage('O valor deve ser um número.'),
];

export const validateCreateCompany: ValidationChain[] = [
  body('fantasyName')
    .isLength({ min: 1 })
    .withMessage('O nome fantasia é obrigatório.'),
  body('cnpj')
    .isLength({ min: 14, max: 14 })
    .withMessage('O CNPJ deve ter 14 caracteres.'),
  body('phone')
    .isMobilePhone('pt-BR')
    .withMessage('Numero de telefone inválido.'),
  body('user').isObject().withMessage('O user é obrigatório.'),
  body('user.name')
    .isString()
    .withMessage('O nome do usuário é obrigatório.')
    .notEmpty()
    .withMessage('O nome do usuário não pode estar vazio.'),
  body('user.email')
    .isEmail()
    .withMessage('O e-mail do usuário deve ser válido.')
    .notEmpty()
    .withMessage('O e-mail do usuário é obrigatório.'),
  body('user.password')
    .isString()
    .withMessage('A senha do usuário é obrigatória.')
    .isLength({ min: 8 })
    .withMessage('A senha deve ter pelo menos 8 caracteres.')
    .matches(/[a-zA-Z]/)
    .withMessage('A senha deve conter pelo menos uma letra.')
    .matches(/\d/)
    .withMessage('A senha deve conter pelo menos um número.')
    .notEmpty()
    .withMessage('A senha do usuário não pode estar vazia.'),
];

export const validateUpdateCompanySetting: ValidationChain[] = [
  body('overdueForLastMonthToCompany')
    .optional()
    .isBoolean()
    .withMessage('O campo overdueForLastMonthToCompany deve ser um boolean.'),
  body('overdueForLastMonthFrequency')
    .optional()
    .isBoolean()
    .withMessage('O campo overdueForLastMonthFrequency deve ser um boolean.'),
  body('overdueNotificationToCompany')
    .optional()
    .isBoolean()
    .withMessage('O campo overdueNotificationToCompany deve ser um boolean.'),
];

export const validateCreateClient: ValidationChain[] = [
  body('name').isLength({ min: 1 }).withMessage('O nome é obrigatório.'),
  body('phone')
    .isMobilePhone('pt-BR')
    .withMessage('Numero de telefone inválido.'),
  body('companyId')
    .isUUID()
    .withMessage('O id da empresa é obrigatório.')
    .notEmpty()
    .withMessage('O id da empresa não pode estar vazio.'),
];

export const validateCreatePayment: ValidationChain[] = [
  body('clientId')
    .isUUID()
    .withMessage('O id do cliente é obrigatório.')
    .notEmpty()
    .withMessage('O id do cliente não pode estar vazio.'),
  body('month')
    .isInt({ min: 0, max: 12 })
    .withMessage('O mês deve ser um número inteiro.'),
  body('year')
    .isInt()
    .withMessage('O ano deve ser um número inteiro.')
    .isInt({
      min: new Date().getFullYear() - 1,
      max: new Date().getFullYear() + 1,
    })
    .withMessage('O ano deve ser correspondente ao ano atual'),
  body('paymentDate')
    .isString()
    .withMessage('A data de pagamento deve ser uma preenchida.'),
];

export const validateUpdatePlan: ValidationChain[] = [
  body('name')
    .optional()
    .isLength({ min: 1 })
    .withMessage('O nome não pode estar vazio.'),
  body('price')
    .optional()
    .isDecimal()
    .withMessage('O valor deve ser um número.'),
];

export const validateUpdateClient: ValidationChain[] = [
  body('name')
    .optional()
    .isLength({ min: 1 })
    .withMessage('O nome é obrigatório.'),
  body('phone')
    .optional()
    .isMobilePhone('pt-BR')
    .withMessage('Numero de telefone inválido.'),
  body('companyId')
    .optional()
    .isUUID()
    .withMessage('O id da empresa é obrigatório.')
    .notEmpty()
    .withMessage('O id da empresa não pode estar vazio.'),
];

export const validateUpdateCompanyNotification: ValidationChain[] = [
  body('overdueForLastMonthToCompany').isBoolean(),
  body('overdueForLastMonthFrequency')
    .isString()
    .isIn(Object.values(ENotificationFrequency))
    .withMessage(
      'A frequência de notificação deve ser uma das opções: daily, first-day, fifth-day, tenth-day, twentieth-day, every-monday, every-thursday, every-friday',
    ),
  body('overdueNotificationToCompany').isBoolean(),
  body('overdueNotificationFrequency')
    .isString()
    .isIn(Object.values(ENotificationFrequency))
    .withMessage(
      'A frequência de notificação deve ser uma das opções: daily, first-day, fifth-day, tenth-day, twentieth-day, every-monday, every-thursday, every-friday',
    ),
];
