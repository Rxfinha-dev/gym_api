/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';

export function errorMiddleware(
  error: any,
  _req: Request,
  res: Response,
  _next: NextFunction,
) {
  const status = error.status || 500;
  const message = error.message || 'Houve um problema com a solicitação';

  console.error(`[Error]: ${message} ${JSON.stringify(error)}`);

  res.status(status).send({
    status,
    message,
    error,
  });
}
