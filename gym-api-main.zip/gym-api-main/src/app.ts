import cors from 'cors';
import dotenv from 'dotenv';
import swaggerUi from 'swagger-ui-express';
import swaggerDocument from './swagger.json';
dotenv.config();

import express from 'express';
import { corsOptions } from './config/cors.config';
import { swaggerOptions } from './config/swagger.config';
import { errorMiddleware } from './middlewares/requestError.middleware';
import router from './routes/index';

const app = express();

app.use(express.json());
app.use(cors(corsOptions));
app.use(router);
app.use(errorMiddleware);

app.use(
  '/docs',
  swaggerUi.serve,
  swaggerUi.setup(swaggerDocument, swaggerOptions),
);

export { app };
