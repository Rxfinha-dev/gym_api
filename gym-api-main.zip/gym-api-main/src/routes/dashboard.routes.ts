import { Router } from 'express';
import { requestValidationHandler } from '../helpers/requestValidationHandle.helper';
import {
  authenticateToken,
  checkPermission,
} from '../middlewares/auth.middleware';
import { createControllerMiddleware } from '../middlewares/createControllerMiddleware.middleware';
import { makeGetHomeDashboardData } from '../modules/dashboard/factories/GetHomeDashboardData.factory';
import { EUserType } from '../modules/user/enums/EUserType.enum';

const router = Router();

router.get(
  '/dashboard',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeGetHomeDashboardData),
);
export default router;
