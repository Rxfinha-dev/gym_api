import { Router } from 'express';
import { requestValidationHandler } from '../helpers/requestValidationHandle.helper';
import {
  authenticateToken,
  checkPermission,
} from '../middlewares/auth.middleware';
import { createControllerMiddleware } from '../middlewares/createControllerMiddleware.middleware';
import { validateCreateUser } from '../middlewares/requestValidators.middleware';
import { EUserType } from '../modules/user/enums/EUserType.enum';
import { makeCreateUserController } from '../modules/user/factories/CreateUserController.factory';
import { makeChangePasswordController } from '../modules/login/factories/ChangePasswordController.factory';

const router = Router();

router.post(
  '/user',
  authenticateToken,
  checkPermission([EUserType.ADMIN]),
  validateCreateUser,
  requestValidationHandler,
  createControllerMiddleware(makeCreateUserController),
);

router.patch(
  '/user/change-password',
  authenticateToken,
  checkPermission([EUserType.ADMIN]),
  requestValidationHandler,
  createControllerMiddleware(makeChangePasswordController),
);

export default router;
