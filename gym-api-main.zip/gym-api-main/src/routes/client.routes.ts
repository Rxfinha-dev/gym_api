import { Router } from 'express';
import { requestValidationHandler } from '../helpers/requestValidationHandle.helper';
import {
  authenticateToken,
  checkPermission,
} from '../middlewares/auth.middleware';
import { createControllerMiddleware } from '../middlewares/createControllerMiddleware.middleware';
import {
  validateCreateClient,
  validateUpdateClient,
} from '../middlewares/requestValidators.middleware';
import { makeCreateClientController } from '../modules/client/factories/CreateClienteController.factory';
import { makeDeleteClientController } from '../modules/client/factories/DeleteClientController.factory';
import { makeFindClientByIdController } from '../modules/client/factories/FindClientById.factory';
import { makeFindClientsAndPaymentsController } from '../modules/client/factories/FindClientsAndPaymentsController.factory';
import { makeFindClientsByCompanyController } from '../modules/client/factories/FindClientsByCompanyController.factory';
import { makeUpdateClientController } from '../modules/client/factories/UpdateClientController.factory';
import { EUserType } from '../modules/user/enums/EUserType.enum';

const router = Router();

router.post(
  '/client',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  validateCreateClient,
  requestValidationHandler,
  createControllerMiddleware(makeCreateClientController),
);

router.get(
  '/client',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeFindClientsByCompanyController),
);
router.delete(
  '/client',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeDeleteClientController),
);

router.get(
  '/client/payment',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeFindClientsAndPaymentsController),
);
router.patch(
  '/client/:clientId',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  validateUpdateClient,
  requestValidationHandler,
  createControllerMiddleware(makeUpdateClientController),
);
router.get(
  '/client/:id',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeFindClientByIdController),
);

export default router;
