import { Router } from 'express';
import { requestValidationHandler } from '../helpers/requestValidationHandle.helper';
import {
  authenticateToken,
  checkPermission,
} from '../middlewares/auth.middleware';
import { createControllerMiddleware } from '../middlewares/createControllerMiddleware.middleware';
import {
  validateCreatePlan,
  validateUpdatePlan,
} from '../middlewares/requestValidators.middleware';
import { makeCreatePlanController } from '../modules/plan/factories/CreatePlanController.factory';
import { makeDeletePlanController } from '../modules/plan/factories/DeletePlanController.factory';
import { makeFindPlanByCompanyController } from '../modules/plan/factories/FindPlanByCompany.factory';
import { makeFindPlanByIdController } from '../modules/plan/factories/FindPlanById.factory';
import { makeUpdatePlanController } from '../modules/plan/factories/UpdatePlanController.factory';
import { EUserType } from '../modules/user/enums/EUserType.enum';

const router = Router();

router.get(
  '/plan',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeFindPlanByCompanyController),
);

router.get(
  '/plan/:id',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeFindPlanByIdController),
);

router.post(
  '/plan',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  validateCreatePlan,
  requestValidationHandler,
  createControllerMiddleware(makeCreatePlanController),
);

router.patch(
  '/plan',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  validateUpdatePlan,
  requestValidationHandler,
  createControllerMiddleware(makeUpdatePlanController),
);

router.delete(
  '/plan',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeDeletePlanController),
);

export default router;
