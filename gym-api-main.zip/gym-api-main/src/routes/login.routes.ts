import { Router } from 'express';
import { requestValidationHandler } from '../helpers/requestValidationHandle.helper';
import { createControllerMiddleware } from '../middlewares/createControllerMiddleware.middleware';
import {
  validateLogin,
  validateRefreshToken,
} from '../middlewares/requestValidators.middleware';
import { makeLoginController } from '../modules/login/factories/LoginController.factory';
import { makeRefreshTokenController } from '../modules/login/factories/RefreshTokenController.factory';
import { makeCheckTokenController } from '../modules/login/factories/CheckTokenController.factory';

const router = Router();

router.post(
  '/login',
  validateLogin,
  requestValidationHandler,
  createControllerMiddleware(makeLoginController),
);

router.post(
  '/refresh-token',
  validateRefreshToken,
  requestValidationHandler,
  createControllerMiddleware(makeRefreshTokenController),
);

router.get(
  '/check-token',
  requestValidationHandler,
  createControllerMiddleware(makeCheckTokenController),
);

export default router;
