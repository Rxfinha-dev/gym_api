import { Router } from 'express';
import { requestValidationHandler } from '../helpers/requestValidationHandle.helper';
import {
  authenticateToken,
  checkPermission,
} from '../middlewares/auth.middleware';
import { createControllerMiddleware } from '../middlewares/createControllerMiddleware.middleware';
import { validateUpdateCompanyNotification } from '../middlewares/requestValidators.middleware';
import { makeUpdateCompanyNotificationController } from '../modules/notifications/factories/UpdateCompanyNotificationController.factory';
import { EUserType } from '../modules/user/enums/EUserType.enum';
import { makeDisconnectController } from '../modules/whatsapp/factories/disconnectController.factory';
import { makeGetConnectionStatusController } from '../modules/whatsapp/factories/getConnectionStatusController.factory';
import { makeGetQrCodeToConnectController } from '../modules/whatsapp/factories/getQrCodeToConnectController.factory';
import { makeSendTestMessageController } from '../modules/whatsapp/factories/sendTestMessage.factory';

const router = Router();

router.patch(
  '/notification',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  validateUpdateCompanyNotification,
  requestValidationHandler,
  createControllerMiddleware(makeUpdateCompanyNotificationController),
);

router.get(
  '/whatsapp/qrcode',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeGetQrCodeToConnectController),
);

router.get(
  '/whatsapp/status',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeGetConnectionStatusController),
);

router.post(
  '/whatsapp/disconnect',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeDisconnectController),
);

router.post(
  '/whatsapp/send-test-message',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeSendTestMessageController),
);
export default router;
