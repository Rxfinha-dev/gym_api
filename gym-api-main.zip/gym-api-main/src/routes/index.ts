import { Router } from 'express';
import ClientRoutes from './client.routes';
import CompanyRoutes from './company.routes';
import DashboardRoutes from './dashboard.routes';
import LoginRoutes from './login.routes';
import PaymentRoutes from './payment.routes';
import PlanRoutes from './plan.routes';
import UserRoutes from './user.routes';
import NotificationRoutes from './notification.routes';

const router = Router();

router.use(LoginRoutes);
router.use(UserRoutes);
router.use(PlanRoutes);
router.use(CompanyRoutes);
router.use(ClientRoutes);
router.use(PaymentRoutes);
router.use(DashboardRoutes);
router.use(NotificationRoutes);

export default router;
