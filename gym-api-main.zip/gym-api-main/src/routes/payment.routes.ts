import { Router } from 'express';
import { requestValidationHandler } from '../helpers/requestValidationHandle.helper';
import {
  authenticateToken,
  checkPermission,
} from '../middlewares/auth.middleware';
import { createControllerMiddleware } from '../middlewares/createControllerMiddleware.middleware';
import { validateCreatePayment } from '../middlewares/requestValidators.middleware';
import { makeCreatePaymentController } from '../modules/payment/factories/CreatePaymentController.factory';
import { EUserType } from '../modules/user/enums/EUserType.enum';

const router = Router();
router.post(
  '/payment',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  validateCreatePayment,
  requestValidationHandler,
  createControllerMiddleware(makeCreatePaymentController),
);
export default router;
