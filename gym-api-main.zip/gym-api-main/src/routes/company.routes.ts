import { Router } from 'express';
import { requestValidationHandler } from '../helpers/requestValidationHandle.helper';
import {
  authenticateToken,
  checkPermission,
} from '../middlewares/auth.middleware';
import { createControllerMiddleware } from '../middlewares/createControllerMiddleware.middleware';
import {
  validateCreateCompany,
  validateUpdateCompanySetting,
} from '../middlewares/requestValidators.middleware';
import { makeCreateCompanyController } from '../modules/company/factories/CreateCompanyController.factory';
import { makeFindCompanyByIdController } from '../modules/company/factories/FindCompanyByIdController.factory';
import { makeGetAllCompaniesController } from '../modules/company/factories/GetAllCompaniesController.factory';
import { EUserType } from '../modules/user/enums/EUserType.enum';
import { makeUpdateCompanySettingController } from '../modules/companySetting/factories/UpdateCompanySettingController.factory';

const router = Router();

router.post(
  '/company',
  authenticateToken,
  checkPermission([EUserType.ADMIN]),
  validateCreateCompany,
  requestValidationHandler,
  createControllerMiddleware(makeCreateCompanyController),
);

router.get(
  '/company',
  authenticateToken,
  checkPermission([EUserType.ADMIN, EUserType.COMPANY]),
  requestValidationHandler,
  createControllerMiddleware(makeFindCompanyByIdController),
);

router.get(
  '/company/all',
  authenticateToken,
  checkPermission([EUserType.ADMIN]),
  requestValidationHandler,
  createControllerMiddleware(makeGetAllCompaniesController),
);

router.patch(
  '/company-setting',
  authenticateToken,
  checkPermission([EUserType.ADMIN]),
  validateUpdateCompanySetting,
  requestValidationHandler,
  createControllerMiddleware(makeUpdateCompanySettingController),
);

export default router;
