import { ICompanyRepository } from '../modules/company/interfaces/ICompanyRepository.interface';
import jwt from 'jsonwebtoken';

export class JwtHelper {
  constructor(private readonly companyRepository: ICompanyRepository) {}

  async checkIfCompanyExistsAndGetTokens(userId: string) {
    const company = await this.companyRepository.findByUserId(userId);

    if (!company) {
      throw new Error('Empresa não encontrada para este usuário.');
    }

    const token = jwt.sign(
      { userId: userId, companyId: company.id },
      process.env.JWT_SECRET as string,
      {
        expiresIn: '3h',
      },
    );

    const refreshToken = jwt.sign(
      { userId: userId, companyId: company.id },
      process.env.REFRESH_TOKEN_SECRET as string,
      {
        expiresIn: '7d',
      },
    );

    return { token, refreshToken, company };
  }
}
