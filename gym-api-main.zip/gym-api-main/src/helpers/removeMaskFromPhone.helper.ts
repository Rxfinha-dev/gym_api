export function removeMaskFromPhone(phoneNumber: string) {
  return phoneNumber.replace(/\D/g, '');
}
