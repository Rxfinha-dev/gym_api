import dotenv from 'dotenv';
dotenv.config();

import { DataSource } from 'typeorm';
import { Users } from '../modules/user/models/User.model';
import { Plans } from '../modules/plan/models/Plan.model';
import { Company } from '../modules/company/models/Company.model';
import { Client } from '../modules/client/models/Client.model';
import { ClientPlans } from '../modules/client/models/ClientPlans.model';
import { Payment } from '../modules/payment/models/Payment.model';
import { CompanySetting } from '../modules/companySetting/models/CompanySetting.model';
import { Notification } from '../modules/notifications/models/Notification.model';
import { WhatsAppSession } from '../modules/whatsapp/models/whatsappSession.model';
import { Exercises } from '../modules/exercises/models/Exercise.model';
import { PresetWorkouts } from '../modules/presetWorkouts/models/PresetWorkouts.model';
import { ExercisePresetWorkouts } from '../modules/exercisePresetWorkouts/models/ExercisePresetWorkouts.model';
import { Workouts } from '../modules/workouts/models/Workouts.model';
import { ExerciseWorkouts } from '../modules/exercisesWorkout/models/ExercisesWorkout.model';

export const AppDataSource = new DataSource({
  type: 'postgres',
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT || '5432'),
  username: process.env.DB_USERNAME,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  entities: [
    Users,
    Plans,
    Company,
    CompanySetting,
    Client,
    ClientPlans,
    Payment,
    Notification,
    WhatsAppSession,
    Exercises,
    PresetWorkouts,
    ExercisePresetWorkouts,
    Workouts,
    ExerciseWorkouts,
  ],
  synchronize: true,
  logging: false,
  ssl: true,
});
