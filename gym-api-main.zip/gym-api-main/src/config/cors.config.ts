import cors from 'cors';

const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:3002',
  'https://v1-gym-front.vercel.app',
  'https://v1-gym-api.vercel.app',
  'https://www.ultimanager.com.br',
];

export const corsOptions: cors.CorsOptions = {
  origin: (origin, callback) => {
    // Permite solicitações sem origem (como aquelas de ferramentas como Postman ou Curl)
    if (!origin) return callback(null, true);
    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      console.error(`Blocked by CORS: ${origin}`);

      callback(new Error('Not allowed by CORS'));
    }
  },
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
  credentials: true,
  optionsSuccessStatus: 204,
};
