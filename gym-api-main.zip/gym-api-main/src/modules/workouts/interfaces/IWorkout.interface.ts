export interface IWorkouts {
  id: string;
  clientId: string;
  presetWorkoutId: string;
  startDate: Date;
  endDate: Date;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}
