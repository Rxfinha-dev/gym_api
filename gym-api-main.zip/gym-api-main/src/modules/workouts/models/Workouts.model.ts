import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
} from 'typeorm';
import { IClient } from '../../client/interfaces/IClient.interface';
import { Client } from '../../client/models/Client.model';
import { PresetWorkouts } from '../../presetWorkouts/models/PresetWorkouts.model';
import { IPresetWorkouts } from '../../presetWorkouts/interfaces/IPresetWorkouts.interface';
import { IWorkouts } from '../interfaces/IWorkout.interface';

@Entity({ name: 'workouts' })
export class Workouts implements IWorkouts {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Client, (client) => client.id)
  client!: IClient;

  @Column()
  clientId: string;

  @ManyToOne(() => PresetWorkouts, (presetWorkout) => presetWorkout.id)
  presetWorkout!: IPresetWorkouts;

  @Column()
  presetWorkoutId: string;

  @Column({ type: 'date' })
  startDate: Date;

  @Column({ type: 'date' })
  endDate: Date;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: IWorkouts) {
    this.id = params?.id || '';
    this.clientId = params?.clientId || '';
    this.presetWorkoutId = params?.presetWorkoutId || '';
    this.startDate = params?.startDate || new Date();
    this.endDate = params?.endDate || new Date();
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
