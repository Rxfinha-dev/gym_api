import { ILike, Repository } from 'typeorm';
import { Plans } from '../models/Plan.model';
import { CreatePlanData } from '../types/createPlan.type';
import { IPlanRepository } from '../interfaces/IPlanRepository.interface';
import { IPlan } from '../interfaces/IPlan.interface';
import { AppDataSource } from '../../../config/typeorm.config';
import { ClientPlans } from '../../client/models/ClientPlans.model';

export class PlanRepository implements IPlanRepository {
  private readonly repository: Repository<Plans>;
  private readonly clientPlansRepository: Repository<ClientPlans>;

  constructor() {
    this.repository = AppDataSource.getRepository(Plans);
    this.clientPlansRepository = AppDataSource.getRepository(ClientPlans);
  }
  async findByClientId(clientId: string): Promise<ClientPlans[] | null> {
    return this.clientPlansRepository.find({
      where: { clientId },
      relations: ['plans'],
    });
  }
  async findByNameAndCompanyId(
    name: string,
    companyId: string,
  ): Promise<IPlan | null> {
    return this.repository.findOneBy({ name, companyId });
  }

  async create(data: CreatePlanData): Promise<IPlan> {
    const plan = this.repository.create(data);
    await this.repository.save(plan);
    return plan;
  }

  async findByCompanyId(
    companyId: string,
    name?: string,
  ): Promise<IPlan[] | null> {
    if (!name || name === 'undefined') {
      return this.repository.findBy({ companyId });
    }

    return this.repository.findBy({ companyId, name: ILike(`%${name}%`) });
  }

  async delete(id: string): Promise<void> {
    await this.repository.softDelete(id);
  }

  async findByIdAndCompanyId(
    id: string,
    companyId: string,
  ): Promise<IPlan | null> {
    return this.repository.findOneBy({ id, companyId });
  }

  async findById(id: string): Promise<IPlan | null> {
    return this.repository.findOneBy({ id });
  }

  async update(plan: IPlan, data: Partial<Plans>): Promise<IPlan | null> {
    Object.assign(plan, data);
    await this.repository.save(plan);

    return plan;
  }
}
