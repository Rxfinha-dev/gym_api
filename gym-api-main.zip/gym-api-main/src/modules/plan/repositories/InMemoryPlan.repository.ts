import { ClientPlans } from '../../client/models/ClientPlans.model';
import { IPlan } from '../interfaces/IPlan.interface';
import { IPlanRepository } from '../interfaces/IPlanRepository.interface';
import { Plans } from '../models/Plan.model';
import { CreatePlanData } from '../types/createPlan.type';

export class InMemoryPlanRepository implements IPlanRepository {
  constructor(public plans: Plans[] = []) {}

  async findByClientId(clientId: string): Promise<ClientPlans[] | null> {
    const plans = this.plans
      .map((plan) => plan.clientPlans)
      .flat()
      .filter((plan) => plan.clientId === clientId);
    return Promise.resolve(plans);
  }

  async findByCompanyId(companyId: string): Promise<IPlan[] | null> {
    const plans = this.plans.filter((plan) => plan.companyId === companyId);
    return Promise.resolve(plans);
  }

  async findByNameAndCompanyId(
    name: string,
    companyId: string,
  ): Promise<IPlan | null> {
    const plan = await Promise.resolve(
      this.plans.find(
        (plan) => plan.name === name && plan.companyId === companyId,
      ),
    );

    if (!plan) {
      return null;
    }

    return plan;
  }

  async create(data: CreatePlanData): Promise<IPlan> {
    const plan = new Plans(data);
    this.plans.push(plan);
    return Promise.resolve(plan);
  }

  async findById(id: string): Promise<IPlan | null> {
    const plan = this.plans.find((plan) => plan.id === id);
    return Promise.resolve(plan as IPlan);
  }
  async delete(id: string): Promise<void> {
    this.plans = this.plans.filter((plan) => plan.id !== id);
  }

  async update(plan: IPlan, data: Partial<Plans>): Promise<IPlan | null> {
    const updatedPlan = this.plans.find((plan) => plan.id === plan.id);
    Object.assign(updatedPlan as IPlan, data);

    return plan as IPlan;
  }

  async findByIdAndCompanyId(
    id: string,
    companyId: string,
  ): Promise<IPlan | null> {
    const plan = this.plans.find(
      (plan) => plan.id === id && plan.companyId === companyId,
    );
    return Promise.resolve(plan as IPlan);
  }
}
