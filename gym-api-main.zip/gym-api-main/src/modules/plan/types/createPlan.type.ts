export type CreatePlanRequest = {
  name: string;
  price: number;
};

export type CreatePlanData = {
  name: string;
  price: number;
  companyId: string;
};
