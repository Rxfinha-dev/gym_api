import { IPlanRepository } from '../interfaces/IPlanRepository.interface';
import { PlanRepository } from '../repositories/Plan.repository';
import { FindPlanByIdController } from '../useCases/findPlanById/findPlanById.controller';
import { FindPlanByIdUseCase } from '../useCases/findPlanById/findPlanById.useCase';

export function makeFindPlanByIdController(planRepo?: IPlanRepository) {
  const planRepository = planRepo ? planRepo : new PlanRepository();
  const findPlanByIdUseCase = new FindPlanByIdUseCase(planRepository);
  const findPlanByIdController = new FindPlanByIdController(
    findPlanByIdUseCase,
  );
  return findPlanByIdController;
}
