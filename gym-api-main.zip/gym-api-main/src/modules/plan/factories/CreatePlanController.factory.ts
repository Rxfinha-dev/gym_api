import { ICompanyRepository } from '../../company/interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../../company/repositories/Company.repository';
import { FindCompanyByIdUseCase } from '../../company/useCases/findCompanyById/findCompanyById.useCase';
import { IPlanRepository } from '../interfaces/IPlanRepository.interface';
import { PlanRepository } from '../repositories/Plan.repository';
import { CreatePlanController } from '../useCases/createPlan/createPlan.controller';
import { CreatePlanUseCase } from '../useCases/createPlan/createPlan.useCase';

export function makeCreatePlanController(
  planRepo?: IPlanRepository,
  companyRepo?: ICompanyRepository,
): CreatePlanController {
  const planRepository = planRepo ? planRepo : new PlanRepository();
  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();

  const findCompanyByIdUseCase = new FindCompanyByIdUseCase(companyRepository);

  const createPlanUseCase = new CreatePlanUseCase(
    planRepository,
    findCompanyByIdUseCase,
  );
  const createPlanController = new CreatePlanController(createPlanUseCase);
  return createPlanController;
}
