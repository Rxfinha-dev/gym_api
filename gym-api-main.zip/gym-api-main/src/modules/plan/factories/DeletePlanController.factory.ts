import { IClientRepository } from '../../client/interfaces/IClientRepository.interface';
import { ClientRepository } from '../../client/repository/Client.repository';
import { IPlanRepository } from '../interfaces/IPlanRepository.interface';
import { PlanRepository } from '../repositories/Plan.repository';
import { DeletePlanController } from '../useCases/deletePlan/deletePlan.controller';
import { DeletePlanUseCase } from '../useCases/deletePlan/deletePlan.useCase';

export function makeDeletePlanController(
  planRepo?: IPlanRepository,
  clientRepo?: IClientRepository,
): DeletePlanController {
  const planRepository = planRepo ? planRepo : new PlanRepository();
  const clientRepository = clientRepo ? clientRepo : new ClientRepository();
  const deletePlanUseCase = new DeletePlanUseCase(
    planRepository,
    clientRepository,
  );
  const deletePlanController = new DeletePlanController(deletePlanUseCase);
  return deletePlanController;
}
