import { IPlanRepository } from '../interfaces/IPlanRepository.interface';
import { PlanRepository } from '../repositories/Plan.repository';
import { UpdatePlanController } from '../useCases/updatePlan/updatePlan.controller';
import { UpdatePlanUseCase } from '../useCases/updatePlan/updatePlan.useCase';

export function makeUpdatePlanController(planRepo?: IPlanRepository) {
  const planRepository = planRepo ? planRepo : new PlanRepository();
  const updatePlanUseCase = new UpdatePlanUseCase(planRepository);
  const updatePlanController = new UpdatePlanController(updatePlanUseCase);
  return updatePlanController;
}
