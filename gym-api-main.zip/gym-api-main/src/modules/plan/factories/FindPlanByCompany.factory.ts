import { IPlanRepository } from '../interfaces/IPlanRepository.interface';
import { PlanRepository } from '../repositories/Plan.repository';
import { FindPlanByCompanyController } from '../useCases/findPlanByCompany/findPlanByCompany.controller';
import { FindPlanByCompanyUseCase } from '../useCases/findPlanByCompany/findPlanByCompany.useCase';

export function makeFindPlanByCompanyController(planRepo?: IPlanRepository) {
  const planRepository = planRepo ? planRepo : new PlanRepository();
  const findPlanByCompanyUseCase = new FindPlanByCompanyUseCase(planRepository);
  const findPlanByCompanyController = new FindPlanByCompanyController(
    findPlanByCompanyUseCase,
  );
  return findPlanByCompanyController;
}
