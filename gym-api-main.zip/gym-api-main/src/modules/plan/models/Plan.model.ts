import { randomUUID } from 'crypto';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Company } from '../../company/models/Company.model';
import { IPlan } from '../interfaces/IPlan.interface';
import { CreatePlanData } from '../types/createPlan.type';
import { ClientPlans } from '../../client/models/ClientPlans.model';

@Entity({ name: 'plans' })
export class Plans implements IPlan {
  @PrimaryColumn()
  id: string;

  @Column()
  name: string;

  @Column({ type: 'float' })
  price: number;

  @Column()
  companyId: string;

  @ManyToOne(() => Company, (company) => company.id)
  @JoinColumn({ name: 'companyId', referencedColumnName: 'id' })
  company!: Company;

  @OneToMany(() => ClientPlans, (clientPlans) => clientPlans.plans)
  clientPlans!: ClientPlans[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: CreatePlanData) {
    this.id = randomUUID();
    this.name = params?.name || '';
    this.price = params?.price || 0;
    this.companyId = params?.companyId || '';
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
