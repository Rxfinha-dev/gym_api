export interface IPlan {
  id: string;
  name: string;
  price: number;
  companyId: string;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}
