import { ClientPlans } from '../../client/models/ClientPlans.model';
import { Plans } from '../models/Plan.model';
import { CreatePlanData } from '../types/createPlan.type';
import { IPlan } from './IPlan.interface';

export interface IPlanRepository {
  create(data: CreatePlanData): Promise<IPlan>;
  findByCompanyId(companyId: string, name?: string): Promise<IPlan[] | null>;
  findByNameAndCompanyId(
    name: string,
    companyId: string,
  ): Promise<IPlan | null>;
  findByIdAndCompanyId(id: string, companyId: string): Promise<IPlan | null>;
  findByClientId(clientId: string): Promise<ClientPlans[] | null>;
  findById(id: string): Promise<IPlan | null>;
  delete(id: string): Promise<void>;
  update(id: IPlan, data: Partial<Plans>): Promise<IPlan | null>;
}
