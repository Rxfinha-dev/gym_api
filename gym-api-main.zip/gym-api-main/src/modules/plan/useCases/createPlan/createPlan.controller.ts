/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { CreatePlanRequest } from '../../types/createPlan.type';
import { CreatePlanUseCase } from './createPlan.useCase';

export class CreatePlanController {
  constructor(private readonly createPlanUseCase: CreatePlanUseCase) {}

  async execute(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    const { companyId } = req.params;
    const data = req.body as CreatePlanRequest;
    try {
      const createUserResponse = await this.createPlanUseCase.execute({
        ...data,
        companyId,
      });
      res.json(createUserResponse);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao criar plano', error });
    }
  }
}
