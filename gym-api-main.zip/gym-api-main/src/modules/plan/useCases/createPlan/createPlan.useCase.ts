import { FindCompanyByIdUseCase } from '../../../company/useCases/findCompanyById/findCompanyById.useCase';
import { IPlan } from '../../interfaces/IPlan.interface';
import { IPlanRepository } from '../../interfaces/IPlanRepository.interface';
import { CreatePlanData } from '../../types/createPlan.type';

export class CreatePlanUseCase {
  constructor(
    private readonly planRepository: IPlanRepository,
    private readonly findCompanyByIdUseCase: FindCompanyByIdUseCase,
  ) {}

  async execute(data: CreatePlanData): Promise<IPlan> {
    await this.findCompanyByIdUseCase.execute(data.companyId);

    const planExists = await this.planRepository.findByNameAndCompanyId(
      data.name,
      data.companyId,
    );

    if (planExists) {
      throw new Error('Este plano já existe para esta empresa');
    }

    const plan = await this.planRepository.create(data);
    return plan;
  }
}
