import { InMemoryCompanyRepository } from '../../../company/repositories/InMemoryCompany.repository';
import { FindCompanyByIdUseCase } from '../../../company/useCases/findCompanyById/findCompanyById.useCase';
import { Plans } from '../../models/Plan.model';
import { InMemoryPlanRepository } from '../../repositories/InMemoryPlan.repository';
import { CreatePlanData } from '../../types/createPlan.type';
import { CreatePlanUseCase } from './createPlan.useCase';

describe('CreatePlanUseCase', () => {
  const mockPlanRepository = new InMemoryPlanRepository();
  const mockCompanyRepository = new InMemoryCompanyRepository();
  const mockFindCompanyByIdUseCase = new FindCompanyByIdUseCase(
    mockCompanyRepository,
  );
  let createPlanUseCase: CreatePlanUseCase;

  beforeEach(() => {
    createPlanUseCase = new CreatePlanUseCase(
      mockPlanRepository,
      mockFindCompanyByIdUseCase,
    );
  });

  it('should be defined', () => {
    expect(createPlanUseCase).toBeDefined();
  });

  it('should create a plan', async () => {
    const createPlanData: CreatePlanData = {
      name: 'Basic Plan',
      price: 29.99,
      companyId: 'random-company-id',
    };

    const result = await createPlanUseCase.execute(createPlanData);

    expect(result).toBeInstanceOf(Plans);
  });
});
