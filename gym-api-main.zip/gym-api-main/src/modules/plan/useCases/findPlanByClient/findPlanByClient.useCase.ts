import { IPlan } from '../../interfaces/IPlan.interface';
import { IPlanRepository } from '../../interfaces/IPlanRepository.interface';

export class FindPlanByClientUseCase {
  constructor(private readonly planRepository: IPlanRepository) {}

  async execute(clientId: string): Promise<IPlan> {
    const plans = await this.planRepository.findByClientId(clientId);

    if (!plans) {
      throw new Error('Nenhum plano encontrado para este cliente');
    }

    const plan = plans.find((plan) => plan.deletedAt === null);

    if (!plan) {
      throw new Error('Nenhum plano ativo encontrado para este cliente');
    }

    return {
      id: plan.plans.id,
      name: plan.plans.name,
      price: plan.plans.price,
      companyId: plan.plans.companyId,
      createdAt: plan.plans.createdAt,
      updatedAt: plan.plans.updatedAt,
      deletedAt: plan.plans.deletedAt,
    };
  }
}
