import { IClientRepository } from '../../../client/interfaces/IClientRepository.interface';
import { IPlanRepository } from '../../interfaces/IPlanRepository.interface';

export class DeletePlanUseCase {
  constructor(
    private readonly planRepository: IPlanRepository,
    private readonly clientRepository: IClientRepository,
  ) {}

  async execute(id: string, companyId: string): Promise<void> {
    const existsPlan = await this.planRepository.findByIdAndCompanyId(
      id,
      companyId,
    );

    if (!existsPlan) {
      throw new Error('O Plano não existe para esta empresa');
    }

    const existClientPlan =
      await this.clientRepository.findClientPlanByPlanId(id);

    if (existClientPlan.length > 0) {
      throw new Error(
        'O Plano não pode ser deletado pois possui vínculo com clientes.',
      );
    }

    await this.planRepository.delete(id);
  }
}
