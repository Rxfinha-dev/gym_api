/* eslint-disable @typescript-eslint/no-explicit-any */
import { DeletePlanUseCase } from './deletePlan.useCase';
import { NextFunction, Request, Response } from 'express';

export class DeletePlanController {
  constructor(private readonly deletePlanUseCase: DeletePlanUseCase) {}

  async execute(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    const { companyId } = req.params;
    const { id } = req.query;
    try {
      await this.deletePlanUseCase.execute(String(id), companyId);
      res.json();
    } catch (error: any) {
      next({ message: error.message || 'Erro ao deletar plano', error });
    }
  }
}
