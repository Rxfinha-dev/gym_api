import { IPlan } from '../../interfaces/IPlan.interface';
import { IPlanRepository } from '../../interfaces/IPlanRepository.interface';

export class UpdatePlanUseCase {
  constructor(private readonly planRepository: IPlanRepository) {}

  async execute(
    id: string,
    companyId: string,
    data: Partial<IPlan>,
  ): Promise<void> {
    const plan = await this.planRepository.findByIdAndCompanyId(id, companyId);

    if (!plan) {
      throw new Error('Plano não encontrado para esta empresa');
    }

    await this.planRepository.update(plan, data);
  }
}
