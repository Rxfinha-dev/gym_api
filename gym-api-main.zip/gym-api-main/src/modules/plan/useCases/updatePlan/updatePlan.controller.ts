/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request } from 'express';
import { IPlan } from '../../interfaces/IPlan.interface';
import { UpdatePlanUseCase } from './updatePlan.useCase';

export class UpdatePlanController {
  constructor(private readonly updatePlanUseCase: UpdatePlanUseCase) {}

  async execute(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    const { planId } = req.query;
    const { companyId } = req.params;
    const data = req.body as Partial<IPlan>;

    if (!planId) {
      throw new Error('Id do plano não informado');
    }

    try {
      await this.updatePlanUseCase.execute(String(planId), companyId, data);
      res.json();
    } catch (error: any) {
      next({ message: error.message || 'Erro ao atualizar plano', error });
    }
  }
}
