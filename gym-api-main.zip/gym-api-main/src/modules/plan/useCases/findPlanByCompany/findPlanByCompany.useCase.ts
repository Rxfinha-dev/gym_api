import { IPlan } from '../../interfaces/IPlan.interface';
import { IPlanRepository } from '../../interfaces/IPlanRepository.interface';

export class FindPlanByCompanyUseCase {
  constructor(private readonly planRepository: IPlanRepository) {}

  async execute(companyId: string, name?: string): Promise<IPlan[]> {
    const plans = await this.planRepository.findByCompanyId(companyId, name);

    if (!plans) {
      throw new Error('Nenhum plano encontrado para esta empresa');
    }

    return plans;
  }
}
