/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { FindPlanByCompanyUseCase } from './findPlanByCompany.useCase';

export class FindPlanByCompanyController {
  constructor(
    private readonly findPlanByCompanyUseCase: FindPlanByCompanyUseCase,
  ) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { companyId } = req.params;
    const { name } = req.query;

    try {
      const plans = await this.findPlanByCompanyUseCase.execute(
        companyId,
        String(name),
      );
      return res.json(plans);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao buscar planos', error });
    }
  }
}
