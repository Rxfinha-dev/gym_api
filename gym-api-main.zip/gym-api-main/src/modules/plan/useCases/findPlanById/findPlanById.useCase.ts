import { IPlan } from '../../interfaces/IPlan.interface';
import { IPlanRepository } from '../../interfaces/IPlanRepository.interface';

export class FindPlanByIdUseCase {
  constructor(private readonly planRepository: IPlanRepository) {}

  async execute(id: string): Promise<IPlan> {
    const plan = await this.planRepository.findById(id);

    if (!plan) {
      throw new Error('Plano não encontrado');
    }

    return plan;
  }
}
