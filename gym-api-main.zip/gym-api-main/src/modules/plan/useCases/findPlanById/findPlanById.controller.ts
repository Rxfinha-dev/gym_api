/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { FindPlanByIdUseCase } from './findPlanById.useCase';

export class FindPlanByIdController {
  constructor(private readonly findPlanByIdUseCase: FindPlanByIdUseCase) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { id } = req.params;
    try {
      const plan = await this.findPlanByIdUseCase.execute(id);
      return res.json(plan);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao buscar plano', error });
    }
  }
}
