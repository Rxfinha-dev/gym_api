import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { IExercisePresetWorkouts } from '../../exercisePresetWorkouts/interfaces/IExercisePresetWorkouts.interface';
import { IPresetWorkouts } from '../interfaces/IPresetWorkouts.interface';
import { ExercisePresetWorkouts } from '../../exercisePresetWorkouts/models/ExercisePresetWorkouts.model';

@Entity({ name: 'preset_workouts' })
export class PresetWorkouts implements IPresetWorkouts {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  @OneToMany(() => ExercisePresetWorkouts, (exercise) => exercise.presetWorkout)
  exercises!: IExercisePresetWorkouts[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: IPresetWorkouts) {
    this.id = params?.id || '';
    this.name = params?.name || '';
    this.description = params?.description;
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
