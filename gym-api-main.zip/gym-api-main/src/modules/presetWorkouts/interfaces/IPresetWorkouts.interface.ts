import { IExercisePresetWorkouts } from '../../exercisePresetWorkouts/interfaces/IExercisePresetWorkouts.interface';

export interface IPresetWorkouts {
  id: string;
  name: string;
  description?: string;
  exercises: IExercisePresetWorkouts[];
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}
