import { EMuscleGroup } from '../enums/EMuscleGroup.enum';

export interface IExercise {
  id: string;
  name: string;
  muscleGroup?: EMuscleGroup;
  description?: string;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}
