export enum EMuscleGroup {
  CHEST = 'Chest',
  BACK = 'Back',
  SHOULDERS = 'Shoulders',
  BICEPS = 'Biceps',
  TRICEPS = 'Triceps',
  LEGS = 'Legs',
  ABS = 'Abs',
  CALVES = 'Calves', // panturrilha
  FOREARMS = 'Forearms', // antebraços
  GLUTES = 'Glutes',
}
