import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
} from 'typeorm';
import { IExercise } from '../interfaces/IExercise.interface';
import { EMuscleGroup } from '../enums/EMuscleGroup.enum';

@Entity({ name: 'exercises' })
export class Exercises implements IExercise {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column({ enum: EMuscleGroup })
  muscleGroup?: EMuscleGroup;

  @Column()
  description?: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: IExercise) {
    this.id = params?.id || '';
    this.name = params?.name || '';
    this.muscleGroup = params?.muscleGroup;
    this.description = params?.description;
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
