import { JwtHelper } from '../../../helpers/jwt.helper';
import { ICompanyRepository } from '../../company/interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../../company/repositories/Company.repository';
import { IUserRepository } from '../../user/interfaces/IUserRepository.interface';
import { UserRepository } from '../../user/repository/User.repository';
import { FindUserByEmailUseCase } from '../../user/useCases/findUserByEmail/findUserByEmail.useCase';
import { LoginController } from '../useCases/login/login.controller';
import { LoginUseCase } from '../useCases/login/login.useCase';

export function makeLoginController(
  userRepo?: IUserRepository,
  companyRepo?: ICompanyRepository,
): LoginController {
  const userRepository = userRepo ? userRepo : new UserRepository();
  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();

  const jwtHelper = new JwtHelper(companyRepository);
  const findUserByEmail = new FindUserByEmailUseCase(userRepository);
  const loginUseCase = new LoginUseCase(findUserByEmail, jwtHelper);
  const loginController = new LoginController(loginUseCase);
  return loginController;
}
