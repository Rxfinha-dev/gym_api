import { IUserRepository } from '../../user/interfaces/IUserRepository.interface';
import { UserRepository } from '../../user/repository/User.repository';
import { ChangePasswordController } from '../useCases/changePassword/changePassword.controller';
import { ChangePasswordUseCase } from '../useCases/changePassword/changePassword.useCase';

export function makeChangePasswordController(userRepo?: IUserRepository) {
  const userRepository = userRepo ? userRepo : new UserRepository();
  const changePasswordUseCase = new ChangePasswordUseCase(userRepository);
  const changePasswordController = new ChangePasswordController(
    changePasswordUseCase,
  );
  return changePasswordController;
}
