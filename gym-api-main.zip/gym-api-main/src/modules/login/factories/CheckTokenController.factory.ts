import { CheckTokenController } from '../useCases/checkToken/checkToken.controller';
import { CheckTokenUseCase } from '../useCases/checkToken/checkToken.useCase';

export function makeCheckTokenController() {
  const checkTokenUseCase = new CheckTokenUseCase();
  const checkTokenController = new CheckTokenController(checkTokenUseCase);
  return checkTokenController;
}
