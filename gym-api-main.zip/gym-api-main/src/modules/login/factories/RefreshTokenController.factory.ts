import { JwtHelper } from '../../../helpers/jwt.helper';
import { ICompanyRepository } from '../../company/interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../../company/repositories/Company.repository';
import { RefreshTokenController } from '../useCases/refreshToken/refreshToken.controller';
import { RefreshTokenUseCase } from '../useCases/refreshToken/refreshToken.useCase';

export function makeRefreshTokenController(companyRepo?: ICompanyRepository) {
  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();
  const jwtHelper = new JwtHelper(companyRepository);

  const refreshTokenUseCase = new RefreshTokenUseCase(jwtHelper);
  const refreshTokenController = new RefreshTokenController(
    refreshTokenUseCase,
  );
  return refreshTokenController;
}
