export type LoginResponse = {
  userId: string;
  companyId: string;
  token: string;
  refreshToken: string;
};
