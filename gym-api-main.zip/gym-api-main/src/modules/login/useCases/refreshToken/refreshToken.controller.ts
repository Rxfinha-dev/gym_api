/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';
import { RefreshTokenUseCase } from './refreshToken.useCase';

export class RefreshTokenController {
  constructor(private readonly refreshTokenUseCase: RefreshTokenUseCase) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { refreshToken } = req.body;

    try {
      if (!refreshToken) {
        return res.status(400).json({ error: 'Refresh token não fornecido.' });
      }

      const { token, refreshToken: newRefreshToken } =
        await this.refreshTokenUseCase.execute(refreshToken);

      return res.json({ token, refreshToken: newRefreshToken });
    } catch (error: any) {
      next({ message: error.message || 'Erro ao fazer login', error });
    }
  }
}
