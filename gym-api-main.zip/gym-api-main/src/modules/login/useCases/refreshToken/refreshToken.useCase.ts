import jwt from 'jsonwebtoken';
import { JwtHelper } from '../../../../helpers/jwt.helper';

export class RefreshTokenUseCase {
  constructor(private readonly jwtHelper: JwtHelper) {}

  async execute(refreshToken: string) {
    try {
      const decoded = jwt.verify(
        refreshToken,
        process.env.REFRESH_TOKEN_SECRET as string,
      );

      const { userId } = decoded as {
        userId: string;
        companyId: string;
      };

      return this.jwtHelper.checkIfCompanyExistsAndGetTokens(userId);
    } catch (error) {
      throw new Error('Erro ao atualizar o token');
    }
  }
}
