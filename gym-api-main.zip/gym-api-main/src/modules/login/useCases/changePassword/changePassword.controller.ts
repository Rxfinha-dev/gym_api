/* eslint-disable @typescript-eslint/no-explicit-any */
import { ChangePasswordUseCase } from '../../useCases/changePassword/changePassword.useCase';
import { NextFunction, Request, Response } from 'express';

export class ChangePasswordController {
  constructor(private readonly changePasswordUseCase: ChangePasswordUseCase) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { userId } = req.params;
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res
        .status(400)
        .json({ message: 'Senha atual e nova senha são obrigatórias.' });
    }

    try {
      await this.changePasswordUseCase.execute(
        userId,
        currentPassword,
        newPassword,
      );
      return res.json({ message: 'Senha alterada com sucesso.' });
    } catch (error: any) {
      next({ message: error.message || 'Erro ao alterar senha', error });
    }
  }
}
