import bcrypt from 'bcrypt';
import { IUserRepository } from '../../../user/interfaces/IUserRepository.interface';

export class ChangePasswordUseCase {
  constructor(private readonly userRepository: IUserRepository) {}

  async execute(
    userId: string,
    currentPassword: string,
    newPassword: string,
  ): Promise<void> {
    // 1. Buscar usuário pelo ID
    const user = await this.userRepository.findById(userId);
    if (!user) {
      throw new Error('Usuário não encontrado.');
    }

    // 2. Verificar se a senha atual está correta
    const isMatch = await bcrypt.compare(currentPassword, user.password);
    if (!isMatch) {
      throw new Error('Senha atual incorreta.');
    }

    // 3. Hash da nova senha
    const hashedNewPassword = await bcrypt.hash(newPassword, 10);

    // 4. Atualizar senha no banco de dados
    await this.userRepository.updatePassword(userId, hashedNewPassword);
  }
}
