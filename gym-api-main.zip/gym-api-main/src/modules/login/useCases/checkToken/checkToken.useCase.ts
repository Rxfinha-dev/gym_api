import jwt from 'jsonwebtoken';

export class CheckTokenUseCase {
  async execute(token: string) {
    const isValid = jwt.verify(token, process.env.JWT_SECRET as string);

    if (!isValid) {
      throw new Error('Token inválido');
    }
  }
}
