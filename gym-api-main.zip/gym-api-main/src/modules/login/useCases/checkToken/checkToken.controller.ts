/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { CheckTokenUseCase } from './checkToken.useCase';

export class CheckTokenController {
  constructor(private readonly checkTokenUseCase: CheckTokenUseCase) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const token = req.query.token as string;

    try {
      if (!token) {
        return res.status(400).json({ error: 'Token não fornecido.' });
      }

      await this.checkTokenUseCase.execute(token);
      return res.status(200).json({ message: 'Token validado com sucesso.' });
    } catch (error: any) {
      next({ message: error.message || 'Erro ao verificar token', error });
    }
  }
}
