/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { LoginUseCase } from './login.useCase';

export class LoginController {
  constructor(private readonly loginUseCase: LoginUseCase) {}

  async execute(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    const { email, password } = req.body;

    try {
      const loginResponse = await this.loginUseCase.execute(email, password);
      res.json(loginResponse);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao fazer login', error });
    }
  }
}
