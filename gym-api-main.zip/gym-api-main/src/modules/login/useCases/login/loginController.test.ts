import { Request, Response, NextFunction } from 'express';
import { LoginController } from './login.controller';
import { LoginUseCase } from './login.useCase';
import { LoginResponse } from '../../types/login.types';

describe('LoginController', () => {
  let loginController: LoginController;
  let loginUseCase: LoginUseCase;
  let req: Partial<Request>;
  let res: Partial<Response>;
  let next: NextFunction;

  beforeEach(() => {
    loginUseCase = {
      execute: jest.fn(),
    } as unknown as LoginUseCase;

    loginController = new LoginController(loginUseCase);

    req = {
      body: {
        email: 'test@example.com',
        password: 'password',
      },
    };

    res = {
      json: jest.fn(),
    } as unknown as Partial<Response>;

    next = jest.fn();
  });

  it('should return login response on successful login', async () => {
    const mockLoginResponse: LoginResponse = {
      userId: '1',
      companyId: '2',
      token: 'mockToken',
      refreshToken: 'mockRefreshToken',
    };

    (loginUseCase.execute as jest.Mock).mockResolvedValue(mockLoginResponse);

    await loginController.execute(req as Request, res as Response, next);

    expect(loginUseCase.execute).toHaveBeenCalledWith(
      'test@example.com',
      'password',
    );
    expect(res.json).toHaveBeenCalledWith(mockLoginResponse);
  });

  it('should call next with an error if login fails', async () => {
    const error = new Error('Login failed');
    (loginUseCase.execute as jest.Mock).mockRejectedValue(error);

    await loginController.execute(req as Request, res as Response, next);

    expect(loginUseCase.execute).toHaveBeenCalledWith(
      'test@example.com',
      'password',
    );
    expect(next).toHaveBeenCalledWith(error);
  });
});
