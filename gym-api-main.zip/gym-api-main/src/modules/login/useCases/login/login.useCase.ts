import bcrypt from 'bcrypt';
import { JwtHelper } from '../../../../helpers/jwt.helper';
import { FindUserByEmailUseCase } from '../../../user/useCases/findUserByEmail/findUserByEmail.useCase';
import { LoginResponse } from '../../types/login.types';

export class LoginUseCase {
  constructor(
    private readonly findUserByEmailUseCase: FindUserByEmailUseCase,
    private readonly jwtHelper: JwtHelper,
  ) {}

  async execute(email: string, password: string): Promise<LoginResponse> {
    const user = await this.findUserByEmailUseCase.execute(email);

    if (!user) {
      throw new Error('Email ou senha inválidos.');
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      throw new Error('Email ou senha inválidos.');
    }

    const { company, token, refreshToken } =
      await this.jwtHelper.checkIfCompanyExistsAndGetTokens(user.id);

    return { userId: user.id, companyId: company.id, token, refreshToken };
  }
}
