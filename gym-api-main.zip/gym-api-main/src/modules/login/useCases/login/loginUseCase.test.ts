import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { FindUserByEmailUseCase } from '../../../user/useCases/findUserByEmail/findUserByEmail.useCase';
import { ICompanyRepository } from '../../../company/interfaces/ICompanyRepository.interface';
import { LoginResponse } from '../../types/login.types';
import { LoginUseCase } from './login.useCase';
import { JwtHelper } from '../../../../helpers/jwt.helper';

jest.mock('bcrypt');
jest.mock('jsonwebtoken');

describe('LoginUseCase', () => {
  let loginUseCase: LoginUseCase;
  let findUserByEmailUseCase: FindUserByEmailUseCase;
  let companyRepository: ICompanyRepository;
  let jwtHelper: JwtHelper;

  beforeEach(() => {
    findUserByEmailUseCase = {
      execute: jest.fn(),
    } as unknown as FindUserByEmailUseCase;

    companyRepository = {
      findByUserId: jest.fn(),
    } as unknown as ICompanyRepository;

    jwtHelper = new JwtHelper(companyRepository);

    loginUseCase = new LoginUseCase(findUserByEmailUseCase, jwtHelper);
  });

  it('should throw an error if user is not found', async () => {
    (findUserByEmailUseCase.execute as jest.Mock).mockResolvedValue(null);

    await expect(
      loginUseCase.execute('test@example.com', 'password'),
    ).rejects.toThrow('Email ou senha inválidos.');
  });

  it('should throw an error if password does not match', async () => {
    const mockUser = { id: '1', password: 'hashedpassword' };
    (findUserByEmailUseCase.execute as jest.Mock).mockResolvedValue(mockUser);
    (bcrypt.compare as jest.Mock).mockResolvedValue(false);

    await expect(
      loginUseCase.execute('test@example.com', 'wrongpassword'),
    ).rejects.toThrow('Email ou senha inválidos.');
  });

  it('should throw an error if company is not found', async () => {
    const mockUser = { id: '1', password: 'hashedpassword' };
    (findUserByEmailUseCase.execute as jest.Mock).mockResolvedValue(mockUser);
    (bcrypt.compare as jest.Mock).mockResolvedValue(true);
    (companyRepository.findByUserId as jest.Mock).mockResolvedValue(null);

    await expect(
      loginUseCase.execute('test@example.com', 'password'),
    ).rejects.toThrow('Empresa não encontrada para este usuário.');
  });

  it('should return tokens and userId, companyId on successful login', async () => {
    const mockUser = { id: '1', password: 'hashedpassword' };
    const mockCompany = { id: '2' };
    const mockToken = 'mockToken';
    const mockRefreshToken = 'mockRefreshToken';

    (findUserByEmailUseCase.execute as jest.Mock).mockResolvedValue(mockUser);
    (bcrypt.compare as jest.Mock).mockResolvedValue(true);
    (companyRepository.findByUserId as jest.Mock).mockResolvedValue(
      mockCompany,
    );
    (jwt.sign as jest.Mock).mockImplementation((payload, secret, options) => {
      if (options.expiresIn === '1h') {
        return mockToken;
      } else if (options.expiresIn === '24h') {
        return mockRefreshToken;
      }
    });

    const result: LoginResponse = await loginUseCase.execute(
      'test@example.com',
      'password',
    );

    expect(result).toEqual({
      userId: mockUser.id,
      companyId: mockCompany.id,
      token: mockToken,
      refreshToken: mockRefreshToken,
    });
  });
});
