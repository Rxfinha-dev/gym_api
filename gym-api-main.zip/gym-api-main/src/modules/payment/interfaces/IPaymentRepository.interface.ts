import { CreatePaymentData } from '../types/CreatePaymentData.type';
import { IPayment } from './IPayment.interface';

export interface IDashboardPaymentData {
  clientsPaidThisMonth: number;
  clientsNotPaidThisMonth: number;
}

export interface IPaymentRepository {
  create(data: CreatePaymentData): Promise<IPayment>;
  findByCompanyId(companyId: string): Promise<IPayment[]>;
  existsByClientCompanyMonthYear(
    clientId: string,
    companyId: string,
    month: number,
    year: number,
  ): Promise<boolean>;
  findByClientId(clientId: string): Promise<IPayment[] | null>;
  getNumberOfPaymentsAndOverduesByCompanyId(
    companyId: string,
  ): Promise<IDashboardPaymentData>;
}
