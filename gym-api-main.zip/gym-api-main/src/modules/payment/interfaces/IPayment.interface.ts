export interface IPayment {
  id: string;
  clientId: string;
  companyId: string;
  paymentDate: Date;
  value: number;
  month: number;
  year: number;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}
