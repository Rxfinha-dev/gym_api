import { IPlanRepository } from '../../plan/interfaces/IPlanRepository.interface';
import { PlanRepository } from '../../plan/repositories/Plan.repository';
import { FindPlanByClientUseCase } from '../../plan/useCases/findPlanByClient/findPlanByClient.useCase';
import { IPaymentRepository } from '../interfaces/IPaymentRepository.interface';
import { PaymentRepository } from '../repositories/Payment.repository';
import { CreatePaymentController } from '../useCases/createPayment/createPayment.controller';
import { CreatePaymentUseCase } from '../useCases/createPayment/createPayment.useCase';

export function makeCreatePaymentController(
  paymentRepo?: IPaymentRepository,
  planRepo?: IPlanRepository,
) {
  const paymentRepository = paymentRepo ? paymentRepo : new PaymentRepository();

  const planRepository = planRepo ? planRepo : new PlanRepository();

  const findPlanByClientUseCase = new FindPlanByClientUseCase(planRepository);

  const createPaymentUseCase = new CreatePaymentUseCase(
    paymentRepository,
    findPlanByClientUseCase,
  );
  const createPaymentController = new CreatePaymentController(
    createPaymentUseCase,
  );
  return createPaymentController;
}
