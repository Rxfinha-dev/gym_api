import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryColumn,
  UpdateDateColumn,
} from 'typeorm';
import { IPayment } from '../interfaces/IPayment.interface';
import { Company } from '../../company/models/Company.model';
import { Client } from '../../client/models/Client.model';
import { randomUUID } from 'crypto';
import { CreatePaymentData } from '../types/CreatePaymentData.type';

@Entity({ name: 'payments' })
export class Payment implements IPayment {
  @PrimaryColumn()
  id: string;

  @Column()
  clientId: string;

  @ManyToOne(() => Client, (client) => client.id)
  @JoinColumn({ name: 'clientId', referencedColumnName: 'id' })
  client!: Client;

  @Column()
  companyId: string;

  @ManyToOne(() => Company, (company) => company.id)
  @JoinColumn({ name: 'companyId', referencedColumnName: 'id' })
  company!: Company;

  @Column()
  paymentDate: Date;

  @Column({ type: 'float' })
  value: number;

  @Column()
  month: number;

  @Column()
  year: number;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: CreatePaymentData) {
    this.id = randomUUID();
    this.clientId = params?.clientId || '';
    this.companyId = params?.companyId || '';
    this.paymentDate = params?.paymentDate || new Date();
    this.value = params?.value || 0;
    this.month = params?.month || 0;
    this.year = params?.year || 0;
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
