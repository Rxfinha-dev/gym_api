export type CreatePaymentData = {
  clientId: string;
  companyId: string;
  paymentDate: Date;
  value: number;
  month: number;
  year: number;
};
