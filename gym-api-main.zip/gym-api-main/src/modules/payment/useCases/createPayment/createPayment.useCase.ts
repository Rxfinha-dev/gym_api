import { FindPlanByClientUseCase } from '../../../plan/useCases/findPlanByClient/findPlanByClient.useCase';
import { IPayment } from '../../interfaces/IPayment.interface';
import { IPaymentRepository } from '../../interfaces/IPaymentRepository.interface';

export class CreatePaymentUseCase {
  constructor(
    private readonly paymentRepository: IPaymentRepository,
    private readonly findPlanByClientUseCase: FindPlanByClientUseCase,
  ) {}

  async execute(
    clientId: string,
    companyId: string,
    month: number,
    year: number,
    paymentDate: Date,
  ): Promise<IPayment> {
    const alreadyExists =
      await this.paymentRepository.existsByClientCompanyMonthYear(
        clientId,
        companyId,
        month,
        year,
      );

    if (alreadyExists) {
      throw new Error('Pagamento para esse cliente, mês e ano ja existe');
    }

    const plan = await this.findPlanByClientUseCase.execute(clientId);

    const payment = this.paymentRepository.create({
      clientId,
      companyId,
      month,
      year,
      paymentDate,
      value: plan.price,
    });

    return payment;
  }
}
