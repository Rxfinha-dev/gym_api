/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';
import { CreatePaymentUseCase } from './createPayment.useCase';

export class CreatePaymentController {
  constructor(private readonly createPaymentUseCase: CreatePaymentUseCase) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { companyId } = req.params;
    const { clientId, month, year, paymentDate } = req.body;

    try {
      const payment = await this.createPaymentUseCase.execute(
        clientId,
        companyId,
        month,
        year,
        new Date(paymentDate),
      );
      return res.json(payment);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao criar pagamento', error });
    }
  }
}
