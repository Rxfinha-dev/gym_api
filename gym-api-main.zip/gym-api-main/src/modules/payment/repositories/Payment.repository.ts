import { Repository } from 'typeorm';
import { AppDataSource } from '../../../config/typeorm.config';
import {
  IDashboardPaymentData,
  IPaymentRepository,
} from '../interfaces/IPaymentRepository.interface';
import { Payment } from '../models/Payment.model';
import { IPayment } from '../interfaces/IPayment.interface';

export class PaymentRepository implements IPaymentRepository {
  private readonly repository: Repository<Payment>;

  constructor() {
    this.repository = AppDataSource.getRepository(Payment);
  }
  async create(data: IPayment): Promise<IPayment> {
    const payment = this.repository.create(data);
    return this.repository.save(payment);
  }
  async findByCompanyId(companyId: string): Promise<IPayment[]> {
    const payments = await this.repository.find({
      where: { companyId },
      relations: ['client', 'client.clientPlans.plans'],
    });

    return payments;
  }

  async findByClientId(clientId: string): Promise<IPayment[] | null> {
    return this.repository.findBy({ clientId });
  }

  async existsByClientCompanyMonthYear(
    clientId: string,
    companyId: string,
    month: number,
    year: number,
  ): Promise<boolean> {
    return this.repository.exist({
      where: {
        clientId,
        companyId,
        month,
        year,
      },
    });
  }

  async getNumberOfPaymentsAndOverduesByCompanyId(
    companyId: string,
  ): Promise<IDashboardPaymentData> {
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth() + 1;
    const currentDay = currentDate.getDate();

    const clientsPaidThisMonth = await this.repository.query(`
      select count("clientId")
      from payments p 
      where p."companyId" = '${companyId}'
      and p."month" = ${currentMonth}
      and p."year" = ${currentYear} 
      and p."deletedAt" is null 
    `);

    const clientsNotPaidThisMonth = await this.repository.query(`
      select count(distinct "id")
      from clients c
      where c."companyId" = '${companyId}' 
      and c."deletedAt" is null
      and c."isActive" = true
      and c."dueDay" < ${currentDay}
      and c.id not in (
        select p."clientId" 
              from payments p 
              where p."companyId" = '${companyId}'
              and p."month" = ${currentMonth}
              and p."year" = ${currentYear}
              and p."deletedAt" is null 
      )
    `);

    return {
      clientsPaidThisMonth: clientsPaidThisMonth[0].count,
      clientsNotPaidThisMonth: clientsNotPaidThisMonth[0].count,
    };
  }
}
