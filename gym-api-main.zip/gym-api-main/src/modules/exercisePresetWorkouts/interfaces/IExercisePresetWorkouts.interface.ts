export interface IExercisePresetWorkouts {
  id: string;
  presetWorkoutId: string;
  exerciseId: string;
  sets: number;
  reps: number;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}
