import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { IExercise } from '../../exercises/interfaces/IExercise.interface';
import { Exercises } from '../../exercises/models/Exercise.model';
import { IPresetWorkouts } from '../../presetWorkouts/interfaces/IPresetWorkouts.interface';
import { PresetWorkouts } from '../../presetWorkouts/models/PresetWorkouts.model';
import { IExercisePresetWorkouts } from '../interfaces/IExercisePresetWorkouts.interface';

@Entity({ name: 'exercise_preset_workouts' })
export class ExercisePresetWorkouts implements IExercisePresetWorkouts {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => PresetWorkouts, (presetWorkout) => presetWorkout.exercises)
  presetWorkout!: IPresetWorkouts;

  @Column()
  presetWorkoutId: string;

  @ManyToOne(() => Exercises, (exercise) => exercise.id)
  exercise!: IExercise;

  @Column()
  exerciseId: string;

  @Column()
  sets: number;

  @Column()
  reps: number;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: IExercisePresetWorkouts) {
    this.id = params?.id || '';
    this.presetWorkoutId = params?.presetWorkoutId || '';
    this.exerciseId = params?.exerciseId || '';
    this.sets = params?.sets || 0;
    this.reps = params?.reps || 0;
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
