export enum EUserGender {
  MALE = 0,
  FEMALE = 1,
  OTHER = 2,
}
