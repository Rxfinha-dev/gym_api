export enum EUserType {
  ADMIN = 0,
  COMPANY = 1,
}
