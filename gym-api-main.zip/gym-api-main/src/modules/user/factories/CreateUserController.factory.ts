import { IUserRepository } from '../../user/interfaces/IUserRepository.interface';
import { UserRepository } from '../repository/User.repository';
import { CreateUserController } from '../useCases/createUser/createUser.controller';
import { CreateUserUseCase } from '../useCases/createUser/createUser.useCase';

export function makeCreateUserController(
  userRepo?: IUserRepository,
): CreateUserController {
  const userRepository = userRepo ? userRepo : new UserRepository();

  const createUserUseCase = new CreateUserUseCase(userRepository);
  const createUserController = new CreateUserController(createUserUseCase);
  return createUserController;
}
