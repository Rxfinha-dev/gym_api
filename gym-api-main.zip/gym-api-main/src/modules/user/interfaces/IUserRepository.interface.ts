import { Users } from '../models/User.model';
import { CreateUserData } from '../types/createUser.type';
import { IUser } from './IUser.interface';

export interface IUserRepository {
  create(data: CreateUserData): Promise<IUser>;
  findByEmail(email: string): Promise<IUser | null>;
  findById(id: string): Promise<Users | null>;
  updatePassword(id: string, password: string): Promise<void>;
}
