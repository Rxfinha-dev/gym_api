import { EUserType } from '../enums/EUserType.enum';

export interface IUser {
  id: string;
  type: EUserType;
  name: string;
  email: string;
  password: string;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}
