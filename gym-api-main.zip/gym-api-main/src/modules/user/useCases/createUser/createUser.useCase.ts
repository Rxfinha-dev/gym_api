import bcrypt from 'bcrypt';
import { EUserType } from '../../enums/EUserType.enum';
import { IUser } from '../../interfaces/IUser.interface';
import { IUserRepository } from '../../interfaces/IUserRepository.interface';
import { CreateUserRequestData } from '../../types/createUser.type';

export class CreateUserUseCase {
  constructor(private readonly userRepository: IUserRepository) {}

  async execute(data: CreateUserRequestData): Promise<IUser> {
    const userExists = await this.userRepository.findByEmail(data.email);
    if (userExists) {
      throw new Error('Já existe um usuário com este e-mail.');
    }

    const user = await this.userRepository.create({
      ...data,
      password: await bcrypt.hash(data.password, 10),
      type: data.type || EUserType.COMPANY,
    });

    return user;
  }
}
