import { EUserType } from '../../enums/EUserType.enum';
import { Users } from '../../models/User.model';
import { InMemoryUserRepository } from '../../repository/InMemoryUser.repository';
import { CreateUserRequestData } from '../../types/createUser.type';
import { CreateUserUseCase } from './createUser.useCase';

describe('CreateUserUseCase', () => {
  const mockUserRepository = new InMemoryUserRepository();
  let createUserUseCase: CreateUserUseCase;

  beforeEach(() => {
    createUserUseCase = new CreateUserUseCase(mockUserRepository);
  });

  it('should create a user successfully', async () => {
    const userData: CreateUserRequestData = {
      type: EUserType.COMPANY,
      name: 'Test User',
      email: 'test@example.com',
      password: 'password',
    };

    const result = await createUserUseCase.execute(userData);

    expect(result).toBeInstanceOf(Users);
    expect(result).toHaveProperty('id');
    expect(result).toHaveProperty('type');
    expect(result).toHaveProperty('name');
    expect(result).toHaveProperty('email');
    expect(result).toHaveProperty('password');
  });
});
