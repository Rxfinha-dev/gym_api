/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { CreateUserRequestData } from '../../types/createUser.type';
import { CreateUserUseCase } from './createUser.useCase';

export class CreateUserController {
  constructor(private readonly createUserUseCase: CreateUserUseCase) {}

  async execute(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    const data = req.body as CreateUserRequestData;
    try {
      const createUserResponse = await this.createUserUseCase.execute(data);
      res.json(createUserResponse);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao criar usuário', error });
    }
  }
}
