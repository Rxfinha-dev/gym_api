import { IUser } from '../../interfaces/IUser.interface';
import { IUserRepository } from '../../interfaces/IUserRepository.interface';

export class FindUserByEmailUseCase {
  constructor(private readonly userRepository: IUserRepository) {}

  async execute(email: string): Promise<IUser | null> {
    return this.userRepository.findByEmail(email);
  }
}
