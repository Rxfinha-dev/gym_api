import { randomUUID } from 'crypto';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  PrimaryColumn,
  UpdateDateColumn,
} from 'typeorm';
import { EUserType } from '../enums/EUserType.enum';
import { IUser } from '../interfaces/IUser.interface';
import { CreateUserData } from '../types/createUser.type';

@Entity()
export class Users implements IUser {
  @PrimaryColumn()
  id: string;

  @Column({ type: 'enum', enum: EUserType })
  type: EUserType;

  @Column()
  name: string;

  @Column({ unique: true })
  email: string;

  @Column()
  password: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: CreateUserData) {
    this.id = randomUUID();
    this.type = params?.type || EUserType.COMPANY;
    this.name = params?.name || '';
    this.email = params?.email || '';
    this.password = params?.password || '';
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
