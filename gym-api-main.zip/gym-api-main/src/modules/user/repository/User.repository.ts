import { Repository } from 'typeorm';
import { Users } from '../models/User.model';
import { CreateUserData } from '../types/createUser.type';
import { IUserRepository } from '../interfaces/IUserRepository.interface';
import { AppDataSource } from '../../../config/typeorm.config';

export class UserRepository implements IUserRepository {
  private readonly repository: Repository<Users>;

  constructor() {
    this.repository = AppDataSource.getRepository(Users);
  }

  async create(data: CreateUserData): Promise<Users> {
    const user = this.repository.create(data);
    await this.repository.save(user);
    return user;
  }

  async findByEmail(email: string): Promise<Users | null> {
    return this.repository.findOne({ where: { email } });
  }

  async findById(id: string): Promise<Users | null> {
    return this.repository.findOne({ where: { id } });
  }

  async updatePassword(id: string, password: string): Promise<void> {
    await this.repository.update(id, { password });
  }
}
