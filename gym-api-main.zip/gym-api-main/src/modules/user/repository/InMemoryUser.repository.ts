import { IUser } from '../interfaces/IUser.interface';
import { IUserRepository } from '../interfaces/IUserRepository.interface';
import { Users } from '../models/User.model';
import { CreateUserData } from '../types/createUser.type';

export class InMemoryUserRepository implements IUserRepository {
  constructor(public users: IUser[] = []) {}
  findById(id: string): Promise<Users | null> {
    throw new Error('Method not implemented.');
  }
  updatePassword(id: string, password: string): Promise<void> {
    throw new Error('Method not implemented.');
  }

  async create(data: CreateUserData): Promise<IUser> {
    const user = new Users(data);
    this.users.push(user);
    return Promise.resolve(user);
  }

  async findByEmail(email: string): Promise<IUser | null> {
    const user = this.users.find((user) => user.email === email);
    return Promise.resolve(user || null);
  }
}
