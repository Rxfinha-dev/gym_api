import bcrypt from 'bcrypt';
import crypto from 'crypto';
import { EUserType } from '../enums/EUserType.enum';
import { IUser } from '../interfaces/IUser.interface';

export const fakeUser = async (): Promise<IUser> => {
  return {
    id: crypto.randomUUID(),
    name: 'fakeUser',
    email: 'teste@teste.com',
    password: await bcrypt.hash('teste', 10),
    type: EUserType.ADMIN,
    createdAt: new Date(),
    updatedAt: new Date(),
    deletedAt: null,
  };
};
