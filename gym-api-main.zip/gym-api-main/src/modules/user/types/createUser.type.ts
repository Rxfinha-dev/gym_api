import { EUserType } from '../enums/EUserType.enum';

export type CreateUserData = {
  type?: EUserType;
  name: string;
  email: string;
  password: string;
};

export type CreateUserRequestData = {
  type?: EUserType;
  name: string;
  email: string;
  password: string;
};
