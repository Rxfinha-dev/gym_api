import { ICompanyRepository } from '../interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../repositories/Company.repository';
import { FindCompanyByIdController } from '../useCases/findCompanyById/findCompanyById.controller';
import { FindCompanyByIdUseCase } from '../useCases/findCompanyById/findCompanyById.useCase';

export function makeFindCompanyByIdController(
  companyRepo?: ICompanyRepository,
) {
  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();
  const findCompanyByIdUseCase = new FindCompanyByIdUseCase(companyRepository);
  const findCompanyByIdController = new FindCompanyByIdController(
    findCompanyByIdUseCase,
  );
  return findCompanyByIdController;
}
