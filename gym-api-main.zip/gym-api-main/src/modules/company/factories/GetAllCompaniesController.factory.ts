import { ICompanyRepository } from '../interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../repositories/Company.repository';
import { GetAllCompaniesController } from '../useCases/getAllCompanies/getAllCompanies.controller';
import { GetAllCompaniesUseCase } from '../useCases/getAllCompanies/getAllCompanies.useCase';

export function makeGetAllCompaniesController(
  companyRepo?: ICompanyRepository,
) {
  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();
  const getAllCompaniesUseCase = new GetAllCompaniesUseCase(companyRepository);
  const getAllCompaniesController = new GetAllCompaniesController(
    getAllCompaniesUseCase,
  );
  return getAllCompaniesController;
}
