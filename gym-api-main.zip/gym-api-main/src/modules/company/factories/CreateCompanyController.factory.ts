import { ICompanySettingRepository } from '../../companySetting/interfaces/ICompanySettingRepository.interface';
import { CompanySettingRepository } from '../../companySetting/repositories/CompanySetting.repository';
import { CreateCompanysettingUseCase } from '../../companySetting/useCases/createCompanySetting/createCompanySetting.useCase';
import { INotificationRepository } from '../../notifications/interfaces/INotificationRepository.interface';
import { NotificationRepository } from '../../notifications/repository/Notifications.repository';
import { CreateCompanyNotificationsUseCase } from '../../notifications/useCases/createCompanyNotification/createCompanyNotification.useCase';
import { IUserRepository } from '../../user/interfaces/IUserRepository.interface';
import { UserRepository } from '../../user/repository/User.repository';
import { CreateUserUseCase } from '../../user/useCases/createUser/createUser.useCase';
import { ICompanyRepository } from '../interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../repositories/Company.repository';
import { CreateCompanyController } from '../useCases/createCompany/createCompany.controller';
import { CreateCompanyUseCase } from '../useCases/createCompany/createCompany.useCase';

export function makeCreateCompanyController(
  companyRepo?: ICompanyRepository,
  userRepo?: IUserRepository,
  companySettingRepo?: ICompanySettingRepository,
  notificationsRepo?: INotificationRepository,
) {
  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();
  const userRepository = userRepo ? userRepo : new UserRepository();
  const companySettingRepository = companySettingRepo
    ? companySettingRepo
    : new CompanySettingRepository();
  const notificationRepository = notificationsRepo
    ? notificationsRepo
    : new NotificationRepository();

  const createUserUserCase = new CreateUserUseCase(userRepository);

  const createCompanySettingUseCase = new CreateCompanysettingUseCase(
    companySettingRepository,
  );

  const createCompanyNotificationsUseCase =
    new CreateCompanyNotificationsUseCase(
      companyRepository,
      notificationRepository,
    );

  const createCompanyUseCase = new CreateCompanyUseCase(
    companyRepository,
    createUserUserCase,
    createCompanySettingUseCase,
    createCompanyNotificationsUseCase,
  );
  const createCompanyController = new CreateCompanyController(
    createCompanyUseCase,
  );
  return createCompanyController;
}
