import { randomUUID } from 'crypto';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryColumn,
  UpdateDateColumn,
} from 'typeorm';
import { CompanySetting } from '../../companySetting/models/CompanySetting.model';
import { Notification } from '../../notifications/models/Notification.model';
import { Users } from '../../user/models/User.model';
import { ICompany } from '../interfaces/ICompany.interfaces';
import { CreateCompanyData } from '../types/createCompany.type';

@Entity({ name: 'companies' })
export class Company implements ICompany {
  @PrimaryColumn()
  id: string;

  @Column()
  fantasyName: string;

  @Column({ unique: true })
  cnpj: string;

  @Column()
  phone: string;

  @Column()
  userId: string;

  @ManyToOne(() => Users, (user) => user.id)
  @JoinColumn({ name: 'userId', referencedColumnName: 'id' })
  user!: Users;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  @OneToOne(() => CompanySetting, (companySetting) => companySetting.company)
  companySetting?: CompanySetting;

  @OneToMany(() => Notification, (notification) => notification.company)
  notifications!: Notification[];

  constructor(params?: CreateCompanyData) {
    this.id = randomUUID();
    this.fantasyName = params?.fantasyName || '';
    this.cnpj = params?.cnpj || '';
    this.phone = params?.phone || '';
    this.userId = params?.userId || '';
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
