import { ICompany } from '../../interfaces/ICompany.interfaces';
import { ICompanyRepository } from '../../interfaces/ICompanyRepository.interface';

export class GetAllCompaniesUseCase {
  constructor(private readonly companyRepository: ICompanyRepository) {}

  async execute(): Promise<ICompany[]> {
    const companies = await this.companyRepository.getAllCompanies();

    if (!companies) {
      throw new Error('Nenhuma Empresa Encontrada');
    }

    return companies;
  }
}
