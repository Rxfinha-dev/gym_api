/* eslint-disable @typescript-eslint/no-explicit-any */
import { GetAllCompaniesUseCase } from './getAllCompanies.useCase';
import { NextFunction, Response, Request } from 'express';

export class GetAllCompaniesController {
  constructor(
    private readonly getAllCompaniesUseCase: GetAllCompaniesUseCase,
  ) {}

  async execute(_: Request, res: Response, next: NextFunction) {
    try {
      const companies = await this.getAllCompaniesUseCase.execute();
      return res.json(companies);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao buscar planos', error });
    }
  }
}
