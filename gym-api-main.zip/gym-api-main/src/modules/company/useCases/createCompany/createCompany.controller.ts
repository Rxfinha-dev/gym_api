/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { CreateCompanyUseCase } from './createCompany.useCase';
import { CreateCompanyRequestData } from '../../types/createCompany.type';

export class CreateCompanyController {
  constructor(private readonly createCompanyUseCase: CreateCompanyUseCase) {}

  async execute(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    try {
      const data = req.body as CreateCompanyRequestData;
      const createdCompany = await this.createCompanyUseCase.execute(data);
      res.json(createdCompany);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao criar empresa', error });
    }
  }
}
