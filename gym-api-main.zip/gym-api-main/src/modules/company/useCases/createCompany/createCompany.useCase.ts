import { CreateCompanysettingUseCase } from '../../../companySetting/useCases/createCompanySetting/createCompanySetting.useCase';
import { ENotificationFrequency } from '../../../notifications/enums/ENotifications.enum';
import { CreateCompanyNotificationsUseCase } from '../../../notifications/useCases/createCompanyNotification/createCompanyNotification.useCase';
import { CreateUserUseCase } from '../../../user/useCases/createUser/createUser.useCase';
import { ICompany } from '../../interfaces/ICompany.interfaces';
import { ICompanyRepository } from '../../interfaces/ICompanyRepository.interface';
import { CreateCompanyRequestData } from '../../types/createCompany.type';

export class CreateCompanyUseCase {
  constructor(
    private readonly companyRepository: ICompanyRepository,
    private readonly createUserUseCase: CreateUserUseCase,
    private readonly createCompanySettingUseCase: CreateCompanysettingUseCase,
    private readonly createCompanyNotificationsUseCase: CreateCompanyNotificationsUseCase,
  ) {}

  async execute(data: CreateCompanyRequestData): Promise<ICompany> {
    const user = await this.createUserUseCase.execute(data.user);

    const company = await this.companyRepository.create({
      cnpj: data.cnpj,
      fantasyName: data.fantasyName,
      phone: data.phone,
      userId: user.id,
    });

    await this.createCompanySettingUseCase.execute(company.id);

    await this.createCompanyNotificationsUseCase.execute(
      company.id,
      false,
      ENotificationFrequency.FIRST_DAY,
      true,
      ENotificationFrequency.DAILY,
    );

    return company;
  }
}
