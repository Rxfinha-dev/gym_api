/* eslint-disable @typescript-eslint/no-explicit-any */
import { FindCompanyByIdUseCase } from './findCompanyById.useCase';
import { Request, Response, NextFunction } from 'express';

export class FindCompanyByIdController {
  constructor(
    private readonly findCompanyByIdUseCase: FindCompanyByIdUseCase,
  ) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    try {
      const { companyId } = req.params;
      const company = await this.findCompanyByIdUseCase.execute(companyId);
      res.json(company);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao buscar empresa', error });
    }
  }
}
