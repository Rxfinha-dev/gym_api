import { ICompanyRepository } from '../../interfaces/ICompanyRepository.interface';

export class FindCompanyByIdUseCase {
  constructor(private readonly companyRepository: ICompanyRepository) {}

  async execute(companyId: string) {
    const company = await this.companyRepository.findById(companyId);

    if (!company) {
      throw new Error('Empresa não encontrada.');
    }

    return company;
  }
}
