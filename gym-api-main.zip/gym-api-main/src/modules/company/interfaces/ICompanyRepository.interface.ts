import { CreateCompanyData } from '../types/createCompany.type';
import { ICompany } from './ICompany.interfaces';

export interface ICompanyRepository {
  create(data: CreateCompanyData): Promise<ICompany>;
  findById(companyId: string): Promise<ICompany | null>;
  findByUserId(userId: string): Promise<ICompany | null>;
  findAllWithNotificationsEnabled(): Promise<ICompany[]>;
  getAllCompanies(): Promise<ICompany[]>;
}
