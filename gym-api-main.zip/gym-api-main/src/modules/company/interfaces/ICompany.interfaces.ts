import { ICompanySetting } from '../../companySetting/models/CompanySetting.model';

export interface ICompany {
  id: string;
  fantasyName: string;
  cnpj: string;
  phone: string;
  userId: string;
  companySetting?: ICompanySetting;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}
