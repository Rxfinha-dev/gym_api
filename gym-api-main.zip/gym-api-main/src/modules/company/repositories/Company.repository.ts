import { Repository } from 'typeorm';
import { ICompany } from '../interfaces/ICompany.interfaces';
import { ICompanyRepository } from '../interfaces/ICompanyRepository.interface';
import { Company } from '../models/Company.model';
import { CreateCompanyData } from '../types/createCompany.type';
import { AppDataSource } from '../../../config/typeorm.config';

export class CompanyRepository implements ICompanyRepository {
  private readonly repository: Repository<Company>;

  constructor() {
    this.repository = AppDataSource.getRepository(Company);
  }

  async findAllWithNotificationsEnabled(): Promise<ICompany[]> {
    return this.repository
      .createQueryBuilder('c')
      .leftJoinAndSelect('c.companySetting', 'cs')
      .where(
        'cs.sendOverdueNotificationToCompany = :sendOverdueNotificationToCompany OR ' +
          'cs.sendOverdueNotificationToClients = :sendOverdueNotificationToClients OR ' +
          'cs.sendOverdueForLastMonthToCompany = :sendOverdueForLastMonthToCompany',
        {
          sendOverdueNotificationToCompany: true,
          sendOverdueNotificationToClients: true,
          sendOverdueForLastMonthToCompany: true,
        },
      )
      .andWhere('c.deletedAt IS NULL')
      .andWhere('cs.deletedAt IS NULL')
      .getMany();
  }

  async findByUserId(userId: string): Promise<ICompany | null> {
    return this.repository.findOneBy({ userId });
  }

  async findById(companyId: string): Promise<ICompany | null> {
    return this.repository.findOne({
      relations: ['companySetting', 'notifications'],
      where: { id: companyId },
    });
  }

  async create(data: CreateCompanyData): Promise<ICompany> {
    const company = this.repository.create(data);

    await this.repository.save(company);
    return company;
  }

  async getAllCompanies(): Promise<ICompany[]> {
    return this.repository.find();
  }
}
