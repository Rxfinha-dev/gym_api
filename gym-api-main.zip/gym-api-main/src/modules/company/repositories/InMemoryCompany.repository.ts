import { ICompany } from '../interfaces/ICompany.interfaces';
import { ICompanyRepository } from '../interfaces/ICompanyRepository.interface';
import { Company } from '../models/Company.model';
import { CreateCompanyData } from '../types/createCompany.type';

export class InMemoryCompanyRepository implements ICompanyRepository {
  constructor(public companies: Company[] = []) {}
  find(): Promise<ICompany[]> {
    throw new Error('Method not implemented.');
  }
  getAllCompanies(): Promise<ICompany[]> {
    throw new Error('Method not implemented.');
  }
  findAllWithNotificationsEnabled(): Promise<ICompany[]> {
    throw new Error('Method not implemented.');
  }
  async findById(companyId: string): Promise<ICompany | null> {
    const company = this.companies.find((company) => company.id === companyId);

    if (!company) {
      return null;
    }
    return Promise.resolve(company);
  }

  async findByUserId(userId: string): Promise<ICompany | null> {
    const company = await Promise.resolve(
      this.companies.find((company) => company.userId === userId),
    );

    if (!company) {
      return null;
    }

    return company;
  }

  async GetAllCompanies():Promise<ICompany[] | null>{
    throw new Error("Erro");
    
  }

  async create(data: CreateCompanyData): Promise<ICompany> {
    const company = new Company(data);
    this.companies.push(company);
    return company;
  }
}
