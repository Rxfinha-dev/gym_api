import { CreateUserRequestData } from '../../user/types/createUser.type';

export type CreateCompanyData = {
  fantasyName: string;
  cnpj: string;
  phone: string;
  userId: string;
};

export type CreateCompanyRequestData = {
  fantasyName: string;
  cnpj: string;
  phone: string;
  user: CreateUserRequestData;
};
