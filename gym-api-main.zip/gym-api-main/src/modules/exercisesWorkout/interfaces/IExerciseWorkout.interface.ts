export interface IExerciseWorkouts {
  id: string;
  workoutId: string;
  exerciseId: string;
  sets: number;
  reps: number;
  weight: number;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}
