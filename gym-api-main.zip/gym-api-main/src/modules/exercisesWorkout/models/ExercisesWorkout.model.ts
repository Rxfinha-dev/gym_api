import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
} from 'typeorm';
import { Workouts } from '../../workouts/models/Workouts.model';
import { IWorkouts } from '../../workouts/interfaces/IWorkout.interface';
import { IExercise } from '../../exercises/interfaces/IExercise.interface';
import { Exercises } from '../../exercises/models/Exercise.model';
import { IExerciseWorkouts } from '../interfaces/IExerciseWorkout.interface';

@Entity({ name: 'exercise_workouts' })
export class ExerciseWorkouts implements IExerciseWorkouts {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Workouts, (workout) => workout.id)
  workout!: IWorkouts;

  @Column()
  workoutId: string;

  @ManyToOne(() => Exercises, (exercise) => exercise.id)
  exercise!: IExercise;

  @Column()
  exerciseId: string;

  @Column()
  sets: number;

  @Column()
  reps: number;

  @Column({ nullable: true })
  weight: number;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: IExerciseWorkouts) {
    this.id = params?.id || '';
    this.workoutId = params?.workoutId || '';
    this.exerciseId = params?.exerciseId || '';
    this.sets = params?.sets || 0;
    this.reps = params?.reps || 0;
    this.weight = params?.weight || 0;
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
