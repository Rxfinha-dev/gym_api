import { create, Whatsapp } from 'venom-bot';
import * as fs from 'fs';
import * as path from 'path';

interface SessionInfo {
  client?: Whatsapp;
  qrCode?: string;
  isReady: boolean;
  qrCodeGeneratedAt?: Date;
}

export class WhatsAppServiceV2 {
  private static instance: WhatsAppServiceV2;
  private sessions: Record<string, SessionInfo> = {};
  private sessionDir: string = path.resolve(__dirname, '../sessions');

  constructor() {
    // this.init();
    // O construtor agora não carrega mais as sessões
  }

  // Método estático para garantir o singleton
  public static getInstance(): WhatsAppServiceV2 {
    if (!WhatsAppServiceV2.instance) {
      WhatsAppServiceV2.instance = new WhatsAppServiceV2();
    }
    return WhatsAppServiceV2.instance;
  }

  // Método assíncrono para inicializar e carregar sessões
  public async init() {
    console.log('loading sessions');

    await this.loadSessions();

    console.log('sessions loaded');
  }

  // Carrega as sessões salvas do servidor
  private async loadSessions() {
    if (!fs.existsSync(this.sessionDir)) {
      fs.mkdirSync(this.sessionDir, { recursive: true });
    }
    const sessionFiles = fs.readdirSync(this.sessionDir);
    console.log('sessionFiles', sessionFiles);
    for (const file of sessionFiles) {
      const filePath = path.join(this.sessionDir, file);
      const sessionData = fs.readFileSync(filePath, 'utf-8');
      const sessionInfo: SessionInfo = JSON.parse(sessionData);

      // Vincular o método sendText novamente se a sessão estiver pronta
      if (sessionInfo.isReady && !sessionInfo.client) {
        console.log(
          `Recuperando cliente para a sessão ${file.replace('.json', '')}`,
        );
        await this.recoverClient(file.replace('.json', ''));
      } else {
        this.sessions[file.replace('.json', '')] = sessionInfo;
      }
    }
  }

  private async recoverClient(sessionName: string): Promise<void> {
    console.log('recovering client ENV -> ', process.env.FOLDER_NAME_TOKEN);
    try {
      // Executa a criação da sessão de forma assíncrona
      const result = await create(
        sessionName,
        (base64Qrimg: string) => {
          // Callback quando o QR Code for gerado
          console.log(`QR Code gerado para a sessão ${sessionName}`);
        },
        (statusSession) => {
          // Callback para o status da sessão
          console.log(`Status da sessão ${sessionName}:`, statusSession);
        },
        {
          folderNameToken: process.env.FOLDER_NAME_TOKEN || 'tokens',
          headless: false, // Rodar sem abrir uma nova janela do navegador
          autoClose: 0, // Não fechar automaticamente,
          updatesLog: true,
          browserPathExecutable: '/usr/bin/chromium',
        },
      );

      // Quando a sessão for criada com sucesso, armazena a sessão no objeto
      this.sessions[sessionName] = {
        client: result, // O client resultante da função 'create'
        isReady: true,
      };

      // Salva a sessão após sua criação
      await this.saveSession(sessionName, this.sessions[sessionName]);

      console.log(`Sessão ${sessionName} recuperada e pronta.`);
    } catch (error) {
      // Caso ocorra algum erro na criação da sessão
      console.error(`Erro ao recuperar a sessão ${sessionName}:`, error);
    }
  }

  // Salva a sessão no servidor (fora do container)
  private saveSession(sessionName: string, sessionInfo: SessionInfo) {
    const filePath = path.join(this.sessionDir, `${sessionName}.json`);
    fs.writeFileSync(
      filePath,
      JSON.stringify({
        ...sessionInfo,
        client: undefined,
        sendText: undefined,
      }),
    );
  }

  // Função para criar uma nova sessão para uma empresa
  public async createNewSession(sessionName: string): Promise<SessionInfo> {
    if (
      this.sessions[sessionName] &&
      this.sessions[sessionName].client?.sendText
    ) {
      return this.sessions[sessionName];
    }

    return new Promise((resolve, reject) => {
      create(
        sessionName,
        (base64Qrimg: string) => {
          console.log('log qrcode');

          // Salva o QR Code enquanto não está conectado
          this.sessions[sessionName] = {
            client: null as any,
            qrCode: base64Qrimg,
            isReady: false,
            qrCodeGeneratedAt: new Date(),
          };
          this.saveSession(sessionName, this.sessions[sessionName]);

          resolve(this.sessions[sessionName]);
        },
        (statusSession) => {
          console.log(`Status da sessão ${sessionName}:`, statusSession);
        },
        {
          folderNameToken: process.env.FOLDER_NAME_TOKEN || 'tokens',
          headless: false, // Rodar sem abrir uma nova janela do navegador
          autoClose: 0, // Não fechar automaticamente,
          updatesLog: true,
          browserPathExecutable: '/usr/bin/chromium',
          // browserPathExecutable: '/usr/bin/google-chrome-stable',
        },
      )
        .then((client) => {
          console.log('log then: ', sessionName);
          // Quando o cliente estiver pronto, salva a sessão
          this.sessions[sessionName] = {
            client,
            isReady: true,
          };
          console.log(
            'log then sessions atualizado',
            this.sessions[sessionName].client?.sendText,
          );
          this.saveSession(sessionName, this.sessions[sessionName]);
          resolve(this.sessions[sessionName]);
        })
        .catch((error) => {
          console.log('log error: ', error);
          reject(error);
        });
    });
  }

  // Função para retornar o QR Code de uma sessão
  public async getQRCode(sessionName: string): Promise<string | null> {
    const session = this.sessions[sessionName];

    console.log('log session getQRCode', session);

    if (
      session &&
      session.qrCode &&
      !session.isReady &&
      session.qrCodeGeneratedAt &&
      session.qrCodeGeneratedAt > new Date(Date.now() - 60000)
    ) {
      return session.qrCode;
    }

    const newSession = await this.createNewSession(sessionName);

    if (newSession.qrCode) {
      return newSession.qrCode;
    }

    if (newSession.isReady) {
      return 'ok';
    }

    return null;
  }

  // Função para enviar mensagem de WhatsApp
  public async sendMessage(sessionName: string, to: string, message: string) {
    // Certifique-se de que a sessão está carregada e o client está pronto
    let session = this.sessions[sessionName];

    console.log('log session sendMessage', session);

    if (!session || !session.isReady) {
      console.log('Sessão não pronta, recuperando cliente...');
      await this.recoverClient(sessionName); // Aguardar até que o cliente esteja pronto
      console.log('cliente recuperado: ', this.sessions);
      session = this.sessions[sessionName];
    }

    if (!session || !session.isReady) {
      throw new Error('Sessão não está pronta ou não foi recuperada.');
    }

    if (session.client?.sendText) {
      console.log('Enviando mensagem com client.sendText...', to, message);
      await session.client?.sendText(`55${to}@c.us`, message);
    } else {
      throw new Error('Método sendText não disponível.');
    }
  }
}
