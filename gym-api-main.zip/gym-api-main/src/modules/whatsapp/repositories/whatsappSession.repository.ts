/* eslint-disable @typescript-eslint/no-explicit-any */
import { Repository } from 'typeorm';
import { SocketState } from 'venom-bot';
import { AppDataSource } from '../../../config/typeorm.config';
import { IWhatsappSessionRepository } from '../interfaces/IWhatsappSessionRepository.interface';
import { WhatsAppSession } from '../models/whatsappSession.model';

export class WhatsappSessionRepository implements IWhatsappSessionRepository {
  private readonly repository: Repository<WhatsAppSession>;

  constructor() {
    this.repository = AppDataSource.getRepository(WhatsAppSession);
  }

  async create(data: Partial<WhatsAppSession>): Promise<WhatsAppSession> {
    const whatsappSession = this.repository.create(data);
    await this.repository.save(whatsappSession);
    return whatsappSession;
  }

  async update(
    sessionId: string,
    data: Partial<WhatsAppSession>,
  ): Promise<WhatsAppSession | null> {
    await this.repository.update(sessionId, data);
    return this.repository.findOneBy({ sessionId });
  }

  async updateByCompanyId(
    companyId: string,
    data: Partial<WhatsAppSession>,
  ): Promise<WhatsAppSession | null> {
    await this.repository.update({ companyId }, data);
    return this.repository.findOneBy({ companyId });
  }

  async findByCompanyId(companyId: string): Promise<WhatsAppSession | null> {
    return this.repository.findOneBy({ companyId });
  }

  async findActiveSessions(): Promise<WhatsAppSession[]> {
    return this.repository.findBy({ status: SocketState.CONNECTED });
  }
}
