import { ICompanyRepository } from '../../company/interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../../company/repositories/Company.repository';
import { DisconnectController } from '../useCase/disconnect/disconnect.controller';
import { DisconnectUseCase } from '../useCase/disconnect/disconnect.useCase';
import { WhatsAppServiceV2 } from '../whatsappBotV2';

export const makeDisconnectController = (companyRepo?: ICompanyRepository) => {
  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();

  const disconnectUseCase = new DisconnectUseCase(
    companyRepository,
    WhatsAppServiceV2.getInstance(),
  );
  return new DisconnectController(disconnectUseCase);
};
