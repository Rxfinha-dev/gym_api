import { ICompanyRepository } from '../../company/interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../../company/repositories/Company.repository';
import { GetQrCodeToConnectController } from '../useCase/getQrCodeToConnect/getQrCodeToConnect.controller';
import { GetQrCodeToConnectUseCase } from '../useCase/getQrCodeToConnect/getQrCodeToConnect.useCase';
import { WhatsAppServiceV2 } from '../whatsappBotV2';

export function makeGetQrCodeToConnectController(
  companyRepo?: ICompanyRepository,
) {
  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();

  const getQrCodeToConnectUseCase = new GetQrCodeToConnectUseCase(
    companyRepository,
    WhatsAppServiceV2.getInstance(),
  );
  return new GetQrCodeToConnectController(getQrCodeToConnectUseCase);
}
