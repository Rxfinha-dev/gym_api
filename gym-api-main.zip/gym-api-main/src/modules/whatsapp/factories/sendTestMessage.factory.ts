import { ICompanyRepository } from '../../company/interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../../company/repositories/Company.repository';
import { SendTestMessageController } from '../useCase/sendTestMessage/sendTestMessage.controller';
import { SendTestMessageUseCase } from '../useCase/sendTestMessage/sendTestMessage.useCase';
import { WhatsAppServiceV2 } from '../whatsappBotV2';

export const makeSendTestMessageController = (
  companyRepo?: ICompanyRepository,
) => {
  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();
  const sendTestMessageUseCase = new SendTestMessageUseCase(
    companyRepository,
    WhatsAppServiceV2.getInstance(),
  );
  return new SendTestMessageController(sendTestMessageUseCase);
};
