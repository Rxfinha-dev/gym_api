import { GetConnectionStatusController } from '../useCase/getConnectionStatus/getConnectionStatus.controller';
import { GetConnectionStatusUseCase } from '../useCase/getConnectionStatus/getConnectionStatus.useCase';
import { WhatsAppServiceV2 } from '../whatsappBotV2';

export const makeGetConnectionStatusController = () => {
  const getConnectionStatusUseCase = new GetConnectionStatusUseCase(
    WhatsAppServiceV2.getInstance(),
  );
  return new GetConnectionStatusController(getConnectionStatusUseCase);
};
