/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { IWhatsappSession } from '../interfaces/IWhatsappSession.interface';

@Entity('whatsapp_sessions')
export class WhatsAppSession implements IWhatsappSession {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'company_id' })
  companyId: string;

  @Column({ name: 'session_id', unique: true })
  sessionId: string;

  @Column({ name: 'status', default: 'disconnected' })
  status: string;

  @Column({ name: 'phone_number' })
  phoneNumber: string;

  @Column({ name: 'disconnect_reason', type: 'varchar', nullable: true })
  disconnectReason: string | null;

  @Column({ name: 'last_connected_at', type: 'timestamp', nullable: true })
  lastConnectedAt: Date | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  @DeleteDateColumn({ name: 'deleted_at', nullable: true })
  deletedAt: Date | null;

  @Column({ name: 'session_data', type: 'jsonb', nullable: true })
  sessionData: Record<string, any> | null;

  constructor(params?: Partial<WhatsAppSession>) {
    this.id = params?.id || '';
    this.companyId = params?.companyId || '';
    this.sessionId = params?.sessionId || '';
    this.status = params?.status || 'disconnected';
    this.phoneNumber = params?.phoneNumber || '';
    this.disconnectReason = params?.disconnectReason || null;
    this.lastConnectedAt = params?.lastConnectedAt || null;
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
    this.sessionData = params?.sessionData || null;
  }
}
