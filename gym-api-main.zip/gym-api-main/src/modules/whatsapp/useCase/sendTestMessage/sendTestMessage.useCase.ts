import { ICompanyRepository } from '../../../company/interfaces/ICompanyRepository.interface';
import { WhatsAppServiceV2 } from '../../whatsappBotV2';

export class SendTestMessageUseCase {
  constructor(
    private readonly companyRepository: ICompanyRepository,
    private readonly whatsappService: WhatsAppServiceV2,
  ) {}

  async execute(companyId: string) {
    const company = await this.companyRepository.findById(companyId);

    if (!company) {
      throw new Error('A empresa não existe.');
    }

    const { phone } = company;

    return this.whatsappService.sendMessage(
      companyId,
      phone,
      `Mensagem teste de ULTIMANAGER enviada às ${new Date().toLocaleTimeString('pt-BR')}.`,
    );
  }
}
