/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { SendTestMessageUseCase } from './sendTestMessage.useCase';

export class SendTestMessageController {
  constructor(
    private readonly sendTestMessageUseCase: SendTestMessageUseCase,
  ) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { companyId } = req.params;

    try {
      await this.sendTestMessageUseCase.execute(companyId);
      res.json();
    } catch (error: any) {
      next({ message: error.message || 'Erro ao enviar mensagem', error });
    }
  }
}
