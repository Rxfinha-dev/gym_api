import { WhatsAppServiceV2 } from '../../whatsappBotV2';

export class GetConnectionStatusUseCase {
  constructor(private readonly whatsappService: WhatsAppServiceV2) {}
  async execute(companyId: string) {
    //TODO: Verificar se a empresa existe

    // return this.whatsappService.getConnectionStatus(companyId);
    throw new Error('Not implemented');
  }
}
