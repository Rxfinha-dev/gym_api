/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';
import { GetConnectionStatusUseCase } from './getConnectionStatus.useCase';

export class GetConnectionStatusController {
  constructor(
    private readonly getConnectionStatusUseCase: GetConnectionStatusUseCase,
  ) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    try {
      const { companyId } = req.params;

      const connectionStatus =
        await this.getConnectionStatusUseCase.execute(companyId);

      res.json({ connectionStatus });
    } catch (error: any) {
      next({ message: error.message || 'Erro ao buscar status', error });
    }
  }
}
