/* eslint-disable @typescript-eslint/no-explicit-any */
import { Response, Request, NextFunction } from 'express';
import { DisconnectUseCase } from './disconnect.useCase';

export class DisconnectController {
  constructor(private readonly disconnectUseCase: DisconnectUseCase) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { companyId } = req.params;

    try {
      await this.disconnectUseCase.execute(companyId);
      res.json();
    } catch (error: any) {
      next({ message: error.message || 'Erro ao desconectar', error });
    }
  }
}
