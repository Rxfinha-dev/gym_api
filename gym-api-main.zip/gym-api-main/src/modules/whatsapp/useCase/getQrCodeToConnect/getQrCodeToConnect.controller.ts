/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { GetQrCodeToConnectUseCase } from './getQrCodeToConnect.useCase';

export class GetQrCodeToConnectController {
  constructor(
    private readonly getQrCodeToConnectUseCase: GetQrCodeToConnectUseCase,
  ) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { companyId } = req.params;
    try {
      const qrCodeImage =
        await this.getQrCodeToConnectUseCase.execute(companyId);

      if (!qrCodeImage) {
        return res.json({
          message:
            'Whatsapp já conectado, não é possível gerar um novo QR Code',
        });
      }

      return res.json({ qrCodeImage });
    } catch (error: any) {
      next({ message: error.message || 'Erro ao buscar qrcode', error });
    }
  }
}
