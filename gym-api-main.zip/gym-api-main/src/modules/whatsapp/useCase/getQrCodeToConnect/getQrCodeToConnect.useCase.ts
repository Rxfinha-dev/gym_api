import { ICompanyRepository } from '../../../company/interfaces/ICompanyRepository.interface';
import { WhatsAppServiceV2 } from '../../whatsappBotV2';

export class GetQrCodeToConnectUseCase {
  constructor(
    private readonly companyRepository: ICompanyRepository,
    private readonly whatsappService: WhatsAppServiceV2,
  ) {}

  async execute(companyId: string) {
    // const company = await this.companyRepository.findById(companyId);

    // if (!company) {
    //   throw new Error('A empresa não existe.');
    // }

    //TODO:Se não tiver nenhum serviço de msg habilitado, lança erro
    //alguma validação?

    return this.whatsappService.getQRCode('main-session');
    // return this.whatsappService.getQRCode(companyId);
  }
}
