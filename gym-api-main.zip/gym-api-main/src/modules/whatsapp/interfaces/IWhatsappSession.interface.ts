/* eslint-disable @typescript-eslint/no-explicit-any */
export interface IWhatsappSession {
  id: string;
  sessionId: string;
  companyId: string;
  status: string;
  phoneNumber: string;
  disconnectReason: string | null;
  lastConnectedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
  sessionData: Record<string, any> | null;
  deletedAt: Date | null;
}
