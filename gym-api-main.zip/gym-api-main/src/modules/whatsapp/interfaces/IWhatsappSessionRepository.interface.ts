import { WhatsAppSession } from '../models/whatsappSession.model';

export interface IWhatsappSessionRepository {
  create(data: Partial<WhatsAppSession>): Promise<WhatsAppSession>;
  findByCompanyId(companyId: string): Promise<WhatsAppSession | null>;
  update(
    sessionId: string,
    data: Partial<WhatsAppSession>,
  ): Promise<WhatsAppSession | null>;
  findActiveSessions(): Promise<WhatsAppSession[]>;
}
