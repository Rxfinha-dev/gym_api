/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { UpdateCompanySettingUseCase } from './updateCompanySetting.useCase';
import { ICompanySetting } from '../../models/CompanySetting.model';

export class UpdateCompanySettingController {
  constructor(
    private readonly updateCompanySettingUseCase: UpdateCompanySettingUseCase,
  ) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { companyId } = req.params;
    const {
      sendOverdueForLastMonthToCompany,
      sendOverdueNotificationToClients,
      sendOverdueNotificationToCompany,
    } = req.body as Partial<ICompanySetting>;

    try {
      if (
        !companyId ||
        (sendOverdueForLastMonthToCompany === undefined &&
          sendOverdueNotificationToClients === undefined &&
          sendOverdueNotificationToCompany === undefined)
      ) {
        throw new Error('Faltam dados para atualizar a configuração');
      }

      const companySetting = await this.updateCompanySettingUseCase.execute(
        companyId,
        {
          sendOverdueForLastMonthToCompany,
          sendOverdueNotificationToClients,
          sendOverdueNotificationToCompany,
        },
      );

      return res.json({
        message: 'Configuração atualizada com sucesso',
        companySetting,
      });
    } catch (error: any) {
      next({
        message: error.message || 'Erro ao atualizar configuração',
        error,
      });
    }
  }
}
