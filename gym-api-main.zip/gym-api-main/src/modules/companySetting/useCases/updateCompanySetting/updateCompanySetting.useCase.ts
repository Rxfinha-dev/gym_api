import { ICompanySettingRepository } from '../../interfaces/ICompanySettingRepository.interface';
import { ICompanySetting } from '../../models/CompanySetting.model';

interface IUpdateCompanySettingData {
  sendOverdueForLastMonthToCompany?: boolean;
  sendOverdueNotificationToClients?: boolean;
  sendOverdueNotificationToCompany?: boolean;
}

export class UpdateCompanySettingUseCase {
  constructor(
    private readonly companySettingRepository: ICompanySettingRepository,
  ) {}

  async execute(
    companyId: string,
    data: Partial<ICompanySetting>,
  ): Promise<void> {
    const companySetting =
      await this.companySettingRepository.findByCompanyId(companyId);

    if (!companySetting) {
      throw new Error('Configuração de empresa não encontrada');
    }

    const {
      sendOverdueForLastMonthToCompany,
      sendOverdueNotificationToClients,
      sendOverdueNotificationToCompany,
    } = data;

    const dataToUpdate: IUpdateCompanySettingData = {};

    if (sendOverdueForLastMonthToCompany !== undefined) {
      dataToUpdate.sendOverdueForLastMonthToCompany =
        sendOverdueForLastMonthToCompany;
    }
    if (sendOverdueNotificationToClients !== undefined) {
      dataToUpdate['sendOverdueNotificationToClients'] =
        sendOverdueNotificationToClients;
    }
    if (sendOverdueNotificationToCompany !== undefined) {
      dataToUpdate['sendOverdueNotificationToCompany'] =
        sendOverdueNotificationToCompany;
    }

    return this.companySettingRepository.updateByCompanyId(companyId, data);
  }
}
