import { ICompanySettingRepository } from '../../interfaces/ICompanySettingRepository.interface';

export class CreateCompanysettingUseCase {
  constructor(
    private readonly companySettingRepository: ICompanySettingRepository,
  ) {}

  async execute(companyId: string): Promise<void> {
    await this.companySettingRepository.create(companyId);
  }
}
