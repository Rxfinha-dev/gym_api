import { ICompanySettingRepository } from '../interfaces/ICompanySettingRepository.interface';
import { CompanySettingRepository } from '../repositories/CompanySetting.repository';
import { UpdateCompanySettingController } from '../useCases/updateCompanySetting/updateCompanySetting.controller';
import { UpdateCompanySettingUseCase } from '../useCases/updateCompanySetting/updateCompanySetting.useCase';

export function makeUpdateCompanySettingController(
  companySettingRepo?: ICompanySettingRepository,
) {
  const companySettingRepository = companySettingRepo
    ? companySettingRepo
    : new CompanySettingRepository();

  const updateCompanySettingUseCase = new UpdateCompanySettingUseCase(
    companySettingRepository,
  );
  const updateCompanySettingController = new UpdateCompanySettingController(
    updateCompanySettingUseCase,
  );
  return updateCompanySettingController;
}
