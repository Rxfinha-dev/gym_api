import { ICompanySetting } from '../models/CompanySetting.model';

export interface ICompanySettingRepository {
  create(companyId: string): Promise<ICompanySetting>;
  updateByCompanyId(
    companyId: string,
    data: Partial<ICompanySetting>,
  ): Promise<void>;
  findByCompanyId(companyId: string): Promise<ICompanySetting | null>;
}
