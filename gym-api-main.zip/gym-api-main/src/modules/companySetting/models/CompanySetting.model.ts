import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Company } from '../../company/models/Company.model';

export interface ICompanySetting {
  id: string;
  companyId: string;
  sendOverdueNotificationToCompany?: boolean;
  sendOverdueNotificationToClients?: boolean;
  sendOverdueForLastMonthToCompany?: boolean;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}

@Entity({ name: 'company_settings' })
export class CompanySetting implements ICompanySetting {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ nullable: false })
  companyId: string;

  @OneToOne(() => Company, (company) => company.companySetting)
  @JoinColumn({ name: 'companyId', referencedColumnName: 'id' })
  company!: Company;

  @Column({ nullable: true })
  sendOverdueNotificationToCompany?: boolean;

  @Column({ nullable: true })
  sendOverdueNotificationToClients?: boolean;

  @Column({ nullable: true })
  sendOverdueForLastMonthToCompany?: boolean;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: ICompanySetting) {
    this.id = params?.id || '';
    this.companyId = params?.companyId || '';
    this.sendOverdueNotificationToCompany =
      params?.sendOverdueNotificationToCompany || false;
    this.sendOverdueNotificationToClients =
      params?.sendOverdueNotificationToClients || false;
    this.sendOverdueForLastMonthToCompany =
      params?.sendOverdueForLastMonthToCompany || false;
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
