import { Repository } from 'typeorm';
import { ICompanySettingRepository } from '../interfaces/ICompanySettingRepository.interface';
import {
  CompanySetting,
  ICompanySetting,
} from '../models/CompanySetting.model';
import { AppDataSource } from '../../../config/typeorm.config';
import { randomUUID } from 'crypto';

export class CompanySettingRepository implements ICompanySettingRepository {
  private readonly repository: Repository<CompanySetting>;

  constructor() {
    this.repository = AppDataSource.getRepository(CompanySetting);
  }
  async create(companyId: string): Promise<ICompanySetting> {
    const companySetting = this.repository.create({
      id: randomUUID(),
      companyId,
      sendOverdueNotificationToCompany: true,
    });
    return this.repository.save(companySetting);
  }

  async updateByCompanyId(
    companyId: string,
    data: Partial<ICompanySetting>,
  ): Promise<void> {
    await this.repository.update({ companyId }, data);
  }

  async findByCompanyId(companyId: string): Promise<ICompanySetting | null> {
    return this.repository.findOneBy({ companyId });
  }
}
