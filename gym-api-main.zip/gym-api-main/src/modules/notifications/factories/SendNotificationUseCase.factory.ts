import { IClientRepository } from '../../client/interfaces/IClientRepository.interface';
import { ClientRepository } from '../../client/repository/Client.repository';
import { ICompanyRepository } from '../../company/interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../../company/repositories/Company.repository';
import { INotificationRepository } from '../interfaces/INotificationRepository.interface';
import { NotificationRepository } from '../repository/Notifications.repository';
import { SendNotificationUseCase } from '../useCases/sendNotification/sendNotification.useCase';
import { WhatsAppServiceV2 } from '../../whatsapp/whatsappBotV2';

export async function makeSendNotificationUseCase(
  companyRepo?: ICompanyRepository,
  notificationRepo?: INotificationRepository,
  clientRepo?: IClientRepository,
) {
  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();

  const notificationRepository = notificationRepo
    ? notificationRepo
    : new NotificationRepository();

  const clientRepository = clientRepo ? clientRepo : new ClientRepository();

  const whatsappService = new WhatsAppServiceV2();
  await whatsappService.init();

  return new SendNotificationUseCase(
    companyRepository,
    notificationRepository,
    clientRepository,
    whatsappService,
  );
}
