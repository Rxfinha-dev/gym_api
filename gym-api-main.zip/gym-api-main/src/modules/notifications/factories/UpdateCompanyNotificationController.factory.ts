import { ICompanyRepository } from '../../company/interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../../company/repositories/Company.repository';
import { INotificationRepository } from '../interfaces/INotificationRepository.interface';
import { NotificationRepository } from '../repository/Notifications.repository';
import { UpdateCompanyNotificationsController } from '../useCases/updateCompanyNotification/updateCompanyNotification.controller';
import { UpdateCompanyNotificationsUseCase } from '../useCases/updateCompanyNotification/updateCompanyNotification.useCase';

export function makeUpdateCompanyNotificationController(
  companyRepo?: ICompanyRepository,
  notificationRepo?: INotificationRepository,
) {
  const notificationRepository = notificationRepo
    ? notificationRepo
    : new NotificationRepository();

  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();

  const updateCompanyNotificationUseCase =
    new UpdateCompanyNotificationsUseCase(
      companyRepository,
      notificationRepository,
    );

  const updateCompanyNotificationController =
    new UpdateCompanyNotificationsController(updateCompanyNotificationUseCase);

  return updateCompanyNotificationController;
}
