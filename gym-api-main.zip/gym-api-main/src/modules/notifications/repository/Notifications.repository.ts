import { In, Repository } from 'typeorm';
import { AppDataSource } from '../../../config/typeorm.config';
import { Notification } from '../models/Notification.model';
import { INotificationRepository } from '../interfaces/INotificationRepository.interface';
import { CreateNotificationData } from '../types/createNotification.type';
import { INotification } from '../interfaces/INotification.interface';
import { randomUUID } from 'crypto';

export class NotificationRepository implements INotificationRepository {
  private readonly repository: Repository<Notification>;

  constructor() {
    this.repository = AppDataSource.getRepository(Notification);
  }

  async findByCompanyIds(companyIds: string[]): Promise<Notification[] | null> {
    return this.repository.findBy({ companyId: In(companyIds) });
  }

  async findByCompanyId(companyId: string): Promise<Notification[] | null> {
    return this.repository.findBy({ companyId });
  }

  async create(data: CreateNotificationData): Promise<Notification> {
    const notification = this.repository.create({ id: randomUUID(), ...data });
    await this.repository.save(notification);
    return notification;
  }
  async update(
    notification: INotification,
    data: Partial<Notification>,
  ): Promise<INotification | null> {
    Object.assign(notification, data);
    await this.repository.save(notification);
    return notification;
  }
}
