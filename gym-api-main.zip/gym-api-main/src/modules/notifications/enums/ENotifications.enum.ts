export enum ENotificationType {
  OVERDUE_NOTIFICATION_TO_COMPANY = 'OVERDUE_NOTIFICATION_TO_COMPANY',
  OVERDUE_NOTIFICATION_TO_CLIENTS = 'OVERDUE_NOTIFICATION_TO_CLIENTS',
  OVERDUE_FOR_LAST_MONTH_TO_COMPANY = 'OVERDUE_FOR_LAST_MONTH_TO_COMPANY',
}

export enum ENotificationFrequency {
  DAILY = 'daily',
  FIRST_DAY = 'first-day',
  FIFTH_DAY = 'fifth-day',
  TENTH_DAY = 'tenth-day',
  FIFTEENTH_DAY = 'fifteenth-day',
  TWENTIETH_DAY = 'twentieth-day',
  EVERY_MONDAY = 'every-monday',
  EVERY_THURSDAY = 'every-thursday',
  EVERY_FRIDAY = 'every-friday',
}

export enum EDisconnectReason {
  TIMEOUT_TO_GET_STATUS = 'TIMEOUT_TO_GET_STATUS',
  MANUAL_DISCONNECT = 'MANUAL_DISCONNECT',
}
