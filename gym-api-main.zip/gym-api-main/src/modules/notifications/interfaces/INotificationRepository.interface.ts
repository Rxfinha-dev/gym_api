import { Notification } from '../models/Notification.model';
import { CreateNotificationData } from '../types/createNotification.type';
import { INotification } from './INotification.interface';

export interface INotificationRepository {
  findByCompanyId(companyId: string): Promise<Notification[] | null>;
  findByCompanyIds(companyIds: string[]): Promise<Notification[] | null>;
  create(data: CreateNotificationData): Promise<Notification>;
  update(
    notification: INotification,
    data: Partial<Notification>,
  ): Promise<INotification | null>;
}
