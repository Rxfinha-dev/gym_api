import {
  ENotificationFrequency,
  ENotificationType,
} from '../enums/ENotifications.enum';

export interface INotification {
  id: string;
  companyId: string;
  enabled: boolean;
  frequency: ENotificationFrequency;
  type: ENotificationType;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}
