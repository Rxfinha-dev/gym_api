import {
  ENotificationFrequency,
  ENotificationType,
} from '../enums/ENotifications.enum';

export type CreateNotificationData = {
  companyId: string;
  enabled: boolean;
  frequency: ENotificationFrequency;
  type: ENotificationType;
};
