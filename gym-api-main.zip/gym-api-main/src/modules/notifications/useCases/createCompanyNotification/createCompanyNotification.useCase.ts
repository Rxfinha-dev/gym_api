import { ICompanyRepository } from '../../../company/interfaces/ICompanyRepository.interface';
import {
  ENotificationFrequency,
  ENotificationType,
} from '../../enums/ENotifications.enum';
import { INotificationRepository } from '../../interfaces/INotificationRepository.interface';

export class CreateCompanyNotificationsUseCase {
  constructor(
    private readonly companyRepository: ICompanyRepository,
    private readonly notificationRepository: INotificationRepository,
  ) {}

  async execute(
    companyId: string,
    overdueForLastMonthToCompany: boolean,
    overdueForLastMonthFrequency: ENotificationFrequency,
    overdueNotificationToCompany: boolean,
    overdueNotificationFrequency: ENotificationFrequency,
  ): Promise<void> {
    const company = await this.companyRepository.findById(companyId);

    if (!company) {
      throw new Error('A empresa não existe.');
    }

    const notifications =
      await this.notificationRepository.findByCompanyId(companyId);

    const createdOverdueNotificationToCompany = notifications?.some(
      (notification) => {
        notification.type === ENotificationType.OVERDUE_NOTIFICATION_TO_COMPANY;
      },
    );

    const createdOverdueForLastMonthToCompany = notifications?.some(
      (notification) => {
        notification.type ===
          ENotificationType.OVERDUE_FOR_LAST_MONTH_TO_COMPANY;
      },
    );

    if (overdueNotificationToCompany && !createdOverdueNotificationToCompany) {
      await this.notificationRepository.create({
        companyId,
        type: ENotificationType.OVERDUE_NOTIFICATION_TO_COMPANY,
        enabled: true,
        frequency: overdueNotificationFrequency,
      });
    }

    if (overdueForLastMonthToCompany && !createdOverdueForLastMonthToCompany) {
      await this.notificationRepository.create({
        companyId,
        type: ENotificationType.OVERDUE_FOR_LAST_MONTH_TO_COMPANY,
        enabled: true,
        frequency: overdueForLastMonthFrequency,
      });
    }
  }
}
