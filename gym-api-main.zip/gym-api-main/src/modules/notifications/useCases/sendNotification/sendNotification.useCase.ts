import { addMaskToPhone } from '../../../../helpers/addMaskToPhone.helper';
import { IClient } from '../../../client/interfaces/IClient.interface';
import { IClientRepository } from '../../../client/interfaces/IClientRepository.interface';
import { ICompany } from '../../../company/interfaces/ICompany.interfaces';
import { ICompanyRepository } from '../../../company/interfaces/ICompanyRepository.interface';
import {
  ENotificationFrequency,
  ENotificationType,
} from '../../enums/ENotifications.enum';
import { INotificationRepository } from '../../interfaces/INotificationRepository.interface';
import { WhatsAppServiceV2 } from '../../../whatsapp/whatsappBotV2';

export class SendNotificationUseCase {
  constructor(
    private readonly companyRepository: ICompanyRepository,
    private readonly notificationRepository: INotificationRepository,
    private readonly clientRepository: IClientRepository,
    private readonly whatsappService: WhatsAppServiceV2,
  ) {}

  private async processNotifications(
    companies: ICompany[],
    notificationType: ENotificationType,
    message: string,
    frequencyCheck: (frequency: ENotificationFrequency, date: Date) => boolean,
  ) {
    const companyIds = companies.map((c) => c.id);
    const notifications =
      await this.notificationRepository.findByCompanyIds(companyIds);

    console.log('Notificações encontradas: ', notifications);

    if (!notifications?.length) {
      console.log(
        `Nenhuma notificação ${notificationType} habilitada foi encontrada.`,
      );
      return;
    }

    const today = new Date();

    for (const company of companies) {
      const notification = notifications.find(
        (n) =>
          n.companyId === company.id &&
          n.type === notificationType &&
          n.enabled === true,
      );

      if (notification && frequencyCheck(notification.frequency, today)) {
        console.log(
          `Enviando notificação de ${notificationType} para:`,
          company.fantasyName,
        );

        const overdueClients = await this.clientRepository.findOverdueClients(
          company.id,
        );

        if (!overdueClients.length) {
          console.log(
            `Não há nenhum cliente atrasado para a empresa ${company.fantasyName}.`,
          );
          continue;
        }

        console.log('Enviando mensagem: ', company.fantasyName, company.phone);

        await this.whatsappService.sendMessage(
          'main-session',
          company.phone,
          this.getMessage(
            message,
            company.fantasyName,
            notificationType,
            overdueClients,
          ),
        );

        console.log('enviou mensagem: ', company.fantasyName, company.phone);
      } else {
        console.log(
          `Notificação ${notificationType} não ativada para:`,
          company.fantasyName,
        );
      }
    }
  }

  private getMessage(
    message: string,
    companyName: string,
    notificationType: ENotificationType,
    overdueClients: IClient[],
  ) {
    const appendToMessage =
      notificationType === ENotificationType.OVERDUE_NOTIFICATION_TO_COMPANY
        ? this.getAppendToOverdueClientsMessage(overdueClients)
        : '';

    return (
      companyName +
      ' - ' +
      new Date().toLocaleDateString('pt-br') +
      '\n\n' +
      message +
      appendToMessage
    );
  }

  private getAppendToOverdueClientsMessage(overdueClients: IClient[]) {
    let appendToMessage = '\n\nClientes atrasados: ';

    if (overdueClients.length === 1) {
      appendToMessage += `${overdueClients[0].name} - ${addMaskToPhone(overdueClients[0].phone)}`;
    } else if (overdueClients.length === 2) {
      appendToMessage += `
    ${overdueClients[0].name} - ${addMaskToPhone(overdueClients[0].phone)},
    ${overdueClients[1].name} - ${addMaskToPhone(overdueClients[1].phone)}
  `;
    } else if (overdueClients.length === 3) {
      appendToMessage += `
    ${overdueClients[0].name} - ${addMaskToPhone(overdueClients[0].phone)},
    ${overdueClients[1].name} - ${addMaskToPhone(overdueClients[1].phone)},
    ${overdueClients[2].name} - ${addMaskToPhone(overdueClients[2].phone)}
  `;
    } else if (overdueClients.length > 3) {
      appendToMessage += `
    ${overdueClients[0].name} - ${addMaskToPhone(overdueClients[0].phone)},
    ${overdueClients[1].name} - ${addMaskToPhone(overdueClients[1].phone)},
    ${overdueClients[2].name} - ${addMaskToPhone(overdueClients[2].phone)}
  
    E mais ${overdueClients.length - 3} ...
  `;
    }

    return appendToMessage;
  }

  private frequencyMatches(
    frequency: ENotificationFrequency,
    date: Date,
  ): boolean {
    const dayOfMonth = date.getDate();
    const dayOfWeek = date.getDay();

    switch (frequency) {
      case ENotificationFrequency.DAILY:
        return true;
      case ENotificationFrequency.FIRST_DAY:
        return dayOfMonth === 1;
      case ENotificationFrequency.FIFTH_DAY:
        return dayOfMonth === 5;
      case ENotificationFrequency.TENTH_DAY:
        return dayOfMonth === 10;
      case ENotificationFrequency.FIFTEENTH_DAY:
        return dayOfMonth === 15;
      case ENotificationFrequency.TWENTIETH_DAY:
        return dayOfMonth === 20;
      case ENotificationFrequency.EVERY_MONDAY:
        return dayOfWeek === 1; // Segunda-feira
      case ENotificationFrequency.EVERY_THURSDAY:
        return dayOfWeek === 4; // Quinta-feira
      case ENotificationFrequency.EVERY_FRIDAY:
        return dayOfWeek === 5; // Sexta-feira
      default:
        throw new Error('Frequência de notificação inválida');
    }
  }

  async execute() {
    console.log('Enviando notificações...');

    const companies =
      await this.companyRepository.findAllWithNotificationsEnabled();

    console.log(
      'Empresas com serviço de notificação habilitado:',
      companies.map((c) => c.fantasyName),
    );

    const overdueNotificationCompanies = companies.filter(
      (c) => c.companySetting?.sendOverdueNotificationToCompany,
    );

    if (overdueNotificationCompanies.length > 0) {
      await this.processNotifications(
        overdueNotificationCompanies,
        ENotificationType.OVERDUE_NOTIFICATION_TO_COMPANY,
        `*Há clientes com pagamentos em atraso!*\n\nVerifique as pendências no ULTIMANAGER. \nAcesse os detalhes aqui: ${process.env.FRONT_URL}/payment?paid=false`,
        this.frequencyMatches,
      );
    }

    const lastMonthNotificationCompanies = companies.filter(
      (c) => c.companySetting?.sendOverdueForLastMonthToCompany,
    );

    if (lastMonthNotificationCompanies.length > 0) {
      const lastMonth = new Date().getMonth();
      const lastYear =
        lastMonth === 0
          ? new Date().getFullYear() - 1
          : new Date().getFullYear();

      await this.processNotifications(
        lastMonthNotificationCompanies,
        ENotificationType.OVERDUE_FOR_LAST_MONTH_TO_COMPANY,
        `*Há clientes que não pagaram no mês passado!*\n\nVerifique as pendências no ULTIMANAGER! \nAcesse os detalhes aqui: ${process.env.FRONT_URL}/payment?month=${lastMonth}&year=${lastYear}&paid=false`,
        () => true, // Executa sempre, pois é mensal
      );
    }
  }
}
