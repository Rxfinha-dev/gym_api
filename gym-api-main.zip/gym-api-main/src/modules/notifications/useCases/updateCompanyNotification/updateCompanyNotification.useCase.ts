import { ICompanyRepository } from '../../../company/interfaces/ICompanyRepository.interface';
import {
  ENotificationFrequency,
  ENotificationType,
} from '../../enums/ENotifications.enum';
import { INotification } from '../../interfaces/INotification.interface';
import { INotificationRepository } from '../../interfaces/INotificationRepository.interface';

export class UpdateCompanyNotificationsUseCase {
  constructor(
    private readonly companyRepository: ICompanyRepository,
    private readonly notificationRepository: INotificationRepository,
  ) {}

  async execute(
    companyId: string,
    overdueForLastMonthToCompany: boolean,
    overdueForLastMonthFrequency: ENotificationFrequency,
    overdueNotificationToCompany: boolean,
    overdueNotificationFrequency: ENotificationFrequency,
  ): Promise<void> {
    const company = await this.companyRepository.findById(companyId);

    if (!company) {
      throw new Error('A empresa não existe.');
    }

    const notifications =
      (await this.notificationRepository.findByCompanyId(companyId)) || [];

    await this.updateOrCreateNotification(
      notifications,
      companyId,
      ENotificationType.OVERDUE_NOTIFICATION_TO_COMPANY,
      overdueNotificationToCompany,
      overdueNotificationFrequency,
    );

    await this.updateOrCreateNotification(
      notifications,
      companyId,
      ENotificationType.OVERDUE_FOR_LAST_MONTH_TO_COMPANY,
      overdueForLastMonthToCompany,
      overdueForLastMonthFrequency,
    );
  }

  private async updateOrCreateNotification(
    notifications: INotification[],
    companyId: string,
    type: ENotificationType,
    enabled: boolean,
    frequency: ENotificationFrequency,
  ): Promise<void> {
    const existingNotification = notifications.find(
      (notification) => notification.type === type,
    );

    if (!existingNotification) {
      if (enabled) {
        await this.notificationRepository.create({
          companyId,
          type,
          enabled,
          frequency,
        });
      }
    } else {
      await this.notificationRepository.update(existingNotification, {
        enabled,
        frequency,
      });
    }
  }
}
