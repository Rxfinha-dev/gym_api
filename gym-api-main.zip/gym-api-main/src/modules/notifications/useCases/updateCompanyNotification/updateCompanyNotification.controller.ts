/* eslint-disable @typescript-eslint/no-explicit-any */
import { UpdateCompanyNotificationsUseCase } from './updateCompanyNotification.useCase';
import { NextFunction, Request, Response } from 'express';

export class UpdateCompanyNotificationsController {
  constructor(
    private readonly updateCompanyNotificationsUseCase: UpdateCompanyNotificationsUseCase,
  ) {}

  async execute(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    const { companyId } = req.params;
    const {
      overdueForLastMonthToCompany,
      overdueForLastMonthFrequency,
      overdueNotificationToCompany,
      overdueNotificationFrequency,
    } = req.body;

    try {
      await this.updateCompanyNotificationsUseCase.execute(
        String(companyId),
        overdueForLastMonthToCompany,
        overdueForLastMonthFrequency,
        overdueNotificationToCompany,
        overdueNotificationFrequency,
      );

      res.json({
        message: 'Notificação atualizada com sucesso',
      });
    } catch (error: any) {
      next({
        message: error.message || 'Erro ao atualizar notificação',
        error,
      });
    }
  }
}
