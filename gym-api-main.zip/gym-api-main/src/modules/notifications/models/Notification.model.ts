import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Company } from '../../company/models/Company.model';
import {
  ENotificationFrequency,
  ENotificationType,
} from '../enums/ENotifications.enum';
import { INotification } from '../interfaces/INotification.interface';

@Entity({ name: 'notifications' })
export class Notification implements INotification {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  companyId: string;

  @ManyToOne(() => Company, (company) => company.notifications)
  @JoinColumn({ name: 'companyId', referencedColumnName: 'id' })
  company!: Company;

  @Column()
  enabled: boolean;

  @Column({ enum: ENotificationType })
  type: ENotificationType;

  @Column()
  frequency: ENotificationFrequency;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: INotification) {
    this.id = params?.id || '';
    this.companyId = params?.companyId || '';
    this.enabled = params?.enabled || false;
    this.frequency = params?.frequency || ENotificationFrequency.DAILY;
    this.type =
      params?.type || ENotificationType.OVERDUE_NOTIFICATION_TO_COMPANY;
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
