import { IPlanRepository } from '../../plan/interfaces/IPlanRepository.interface';
import { PlanRepository } from '../../plan/repositories/Plan.repository';
import { IClientRepository } from '../interfaces/IClientRepository.interface';
import { ClientRepository } from '../repository/Client.repository';
import { UpdateClientController } from '../useCases/updateClient/updateClient.controller';
import { UpdateClientUseCase } from '../useCases/updateClient/updateClient.useCase';

export function makeUpdateClientController(
  clientRepo?: IClientRepository,
  planRepo?: IPlanRepository,
) {
  const clientRepository = clientRepo ? clientRepo : new ClientRepository();
  const planRepository = planRepo ? planRepo : new PlanRepository();
  const updateClientUseCase = new UpdateClientUseCase(
    clientRepository,
    planRepository,
  );
  const updateClientController = new UpdateClientController(
    updateClientUseCase,
  );
  return updateClientController;
}
