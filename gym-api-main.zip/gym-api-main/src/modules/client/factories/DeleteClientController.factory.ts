import { IPaymentRepository } from "../../payment/interfaces/IPaymentRepository.interface";
import { PaymentRepository } from "../../payment/repositories/Payment.repository";
import { IClientRepository } from "../interfaces/IClientRepository.interface";
import { ClientRepository } from "../repository/Client.repository";
import { DeleteClientController } from "../useCases/deleteClient/deleteClient.controller";
import { DeleteClientUseCase } from "../useCases/deleteClient/deleteClient.useCase";

export function makeDeleteClientController(
    clientRepo?: IClientRepository,
    paymentRepo?: IPaymentRepository
):DeleteClientController{
    const clientRepository = clientRepo ? clientRepo : new ClientRepository( );
    const paymentRepository = paymentRepo ? paymentRepo : new PaymentRepository();
    const deleteClientUseCase = new DeleteClientUseCase(clientRepository, paymentRepository);
    const deleteClientController = new DeleteClientController(deleteClientUseCase);
    return deleteClientController;
}