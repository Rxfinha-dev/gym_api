import { IClientRepository } from '../interfaces/IClientRepository.interface';
import { ClientRepository } from '../repository/Client.repository';
import { FindClientByIdController } from '../useCases/findClientById/findClientById.controller';
import { FindClientByIdUseCase } from '../useCases/findClientById/findClientById.useCase';

export function makeFindClientByIdController(clientRepo?: IClientRepository) {
  const clientRepository = clientRepo ? clientRepo : new ClientRepository();
  const findClientByIdUseCase = new FindClientByIdUseCase(clientRepository);
  const findClientByIdController = new FindClientByIdController(
    findClientByIdUseCase,
  );
  return findClientByIdController;
}
