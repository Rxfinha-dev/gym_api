import { IClientRepository } from '../interfaces/IClientRepository.interface';
import { ClientRepository } from '../repository/Client.repository';
import { FindClientsByCompanyController } from '../useCases/findClientsByCompany/findClientsByCompany.controller';
import { FindClientsByCompanyUseCase } from '../useCases/findClientsByCompany/findClientsByCompany.useCase';

export function makeFindClientsByCompanyController(
  clientRepo?: IClientRepository,
) {
  const clientRepository = clientRepo ? clientRepo : new ClientRepository();
  const findClientsByCompanyUseCase = new FindClientsByCompanyUseCase(
    clientRepository,
  );
  const findClientsByCompanyController = new FindClientsByCompanyController(
    findClientsByCompanyUseCase,
  );
  return findClientsByCompanyController;
}
