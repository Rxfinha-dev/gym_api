import { IClientRepository } from '../interfaces/IClientRepository.interface';
import { ClientRepository } from '../repository/Client.repository';
import { FindClientsAndPaymentsController } from '../useCases/findClientsAndPayments/findClientsAndPayments.controller';
import { FindClientsAndPaymentsUseCase } from '../useCases/findClientsAndPayments/findClientsAndPayments.useCase';

export function makeFindClientsAndPaymentsController(
  clientRepo?: IClientRepository,
) {
  const paymentRepository = clientRepo ? clientRepo : new ClientRepository();
  const findClientsAndPaymentsUseCase = new FindClientsAndPaymentsUseCase(
    paymentRepository,
  );
  const findClientsAndPaymentsController = new FindClientsAndPaymentsController(
    findClientsAndPaymentsUseCase,
  );
  return findClientsAndPaymentsController;
}
