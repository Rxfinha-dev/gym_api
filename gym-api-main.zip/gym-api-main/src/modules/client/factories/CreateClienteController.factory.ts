import { ICompanyRepository } from '../../company/interfaces/ICompanyRepository.interface';
import { CompanyRepository } from '../../company/repositories/Company.repository';
import { FindCompanyByIdUseCase } from '../../company/useCases/findCompanyById/findCompanyById.useCase';
import { IClientRepository } from '../interfaces/IClientRepository.interface';
import { ClientRepository } from '../repository/Client.repository';
import { CreateClientUseCase } from '../useCases/createClient/createClient.useCase';
import { CreateClientController } from '../useCases/createClient/createCliente.controller';

export function makeCreateClientController(
  companyRepo?: ICompanyRepository,
  clientRepo?: IClientRepository,
) {
  const companyRepository = companyRepo ? companyRepo : new CompanyRepository();
  const clientRepository = clientRepo ? clientRepo : new ClientRepository();
  const findCompanyByIdUseCase = new FindCompanyByIdUseCase(companyRepository);
  const createClientUseCase = new CreateClientUseCase(
    clientRepository,
    findCompanyByIdUseCase,
  );
  const createClientController = new CreateClientController(
    createClientUseCase,
  );
  return createClientController;
}
