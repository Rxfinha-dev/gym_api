/* eslint-disable @typescript-eslint/no-explicit-any */
import { Equal, ILike, LessThanOrEqual, Repository } from 'typeorm';
import { AppDataSource } from '../../../config/typeorm.config';
import { IClient, IUpdateClient } from '../interfaces/IClient.interface';
import { IClientRepository } from '../interfaces/IClientRepository.interface';
import { Client } from '../models/Client.model';
import { ClientPlans } from '../models/ClientPlans.model';
import { CreateClientData } from '../types/createClient.type';
import { FindClientsResponse } from '../types/findClientsResponse.type';
import { ClientPaymentFilters } from '../types/findClientsFilter.type';

export interface IClientFilters extends Partial<IClient> {
  planId?: string;
  limit?: number;
  page?: number;
}

export interface IClientPagination {
  clients: IClient[];
  totalClients: number;
}
export class ClientRepository implements IClientRepository {
  private readonly repository: Repository<Client>;
  private readonly clientPlansRepository: Repository<ClientPlans>;

  constructor() {
    this.repository = AppDataSource.getRepository(Client);
    this.clientPlansRepository = AppDataSource.getRepository(ClientPlans);
  }

  async findByCompanyId(
    companyId: string,
    filters: IClientFilters,
  ): Promise<IClientPagination> {
    const whereConditions: any = {
      companyId,
    };

    if (filters.name) {
      whereConditions['name'] = ILike(`%${filters.name}%`);
    }

    if (filters.dueDay) {
      whereConditions['dueDay'] = Equal(filters.dueDay);
    }

    if (filters.isActive !== undefined) {
      whereConditions['isActive'] = filters.isActive;
    }

    if (filters.planId) {
      whereConditions['clientPlans'] = { planId: filters.planId };
    }

    if (filters.phone) {
      whereConditions['phone'] = ILike(`%${filters.phone}%`);
    }

    const [clients, totalClients] = await this.repository.findAndCount({
      where: { companyId, ...whereConditions },
      relations: ['clientPlans.plans'],
      order: { isActive: 'DESC', name: 'ASC' },
      take: filters.limit || 10,
      skip: filters.page ? (filters.page - 1) * (filters.limit || 10) : 0,
    });

    return {
      clients: clients.map((client) => {
        return {
          id: client.id,
          name: client.name,
          phone: client.phone,
          dueDay: client.dueDay,
          companyId: client.companyId,
          isActive: client.isActive,
          createdAt: client.createdAt,
          updatedAt: client.updatedAt,
          deletedAt: client.deletedAt,
          plans: client.clientPlans.map((clientPlan) => clientPlan.plans),
        };
      }),
      totalClients,
    };
  }
  async create(data: CreateClientData): Promise<IClient> {
    const queryRunner = AppDataSource.createQueryRunner();

    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const client = this.repository.create(data);
      await queryRunner.manager.save(client);

      const clientPlan = this.clientPlansRepository.create({
        clientId: client.id,
        planId: data.planId,
      });

      await queryRunner.manager.save(clientPlan);

      await queryRunner.commitTransaction();

      return client;
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  async existsByNameAndCompanyId(
    companyId: string,
    name: string,
  ): Promise<boolean> {
    return this.repository.exist({
      where: {
        name,
        companyId,
      },
    });
  }

  async findClients(
    filters: ClientPaymentFilters,
  ): Promise<FindClientsResponse[]> {
    const { companyId, month, year, clientName, dueDay } = filters;

    const whereConditions: any = { companyId };

    if (clientName) {
      whereConditions.name = ILike(`%${clientName}%`);
    }

    if (month && year) {
      const endDate = new Date(year, month, 0, 23, 59, 59, 999); // Último dia do mês especificado, até o último milissegundo
      whereConditions.createdAt = LessThanOrEqual(endDate);
    }

    if (dueDay) {
      whereConditions.dueDay = dueDay;
    }

    const clients = await this.repository.find({
      where: { isActive: true, ...whereConditions },
      relations: ['clientPlans', 'clientPlans.plans'],
      select: ['id', 'name', 'phone', 'dueDay'],
    });

    const payments = await this.repository.query(`
      select p.id, p."clientId", p."month", p."year", p."paymentDate", p.value 
      from payments p 
      where p."companyId" = '${companyId}'
      and p."month" = ${month}
      and p."year" = ${year}
      and p."deletedAt" is null
    `);

    const result: FindClientsResponse[] = clients
      .filter((client) => {
        const clientPayments = payments.filter(
          (payment: { clientId: string }) => payment.clientId === client.id,
        );
        const paid = clientPayments.length > 0;

        return paid || client.isActive === true;
      })
      .map((client) => {
        const clientPayments = payments.filter(
          (payment: { clientId: string }) => payment.clientId === client.id,
        );
        const paid = clientPayments.length > 0;
        const plan = client.clientPlans[0].plans;

        return {
          id: client.id,
          name: client.name,
          phone: client.phone,
          companyId: client.companyId,
          createdAt: client.createdAt,
          updatedAt: client.updatedAt,
          deletedAt: client.deletedAt,
          paid,
          dueDay: client.dueDay,
          plan,
          payments: clientPayments,
        };
      })
      .sort((a, b) => a.dueDay - b.dueDay);

    return result;
  }

  async findOverdueClients(companyId: string): Promise<Client[]> {
    const today = new Date();
    const day = today.getDate();
    const month = today.getMonth() + 1;
    const year = today.getFullYear();

    return this.repository.query(`
        select c.id, c.name, c.phone
        from clients c 
        where c."isActive" = true
        and c."companyId" = '${companyId}'
        and c."deletedAt" is null
        and c."dueDay" < ${day}
        and c.id not in (
          select p."clientId" 
          from payments p
          where p."companyId" = '${companyId}'
          and p."month" = ${month}
          and p."year" = ${year}
          and p."deletedAt" is null
        )
      `);
  }

  async findClientPlanByPlanId(planId: string): Promise<ClientPlans[]> {
    return this.clientPlansRepository.find({
      where: { planId },
    });
  }

  async findClientPlanByClientId(clientId: string): Promise<ClientPlans[]> {
    return this.clientPlansRepository.find({
      where: { clientId },
    });
  }

  async delete(id: string): Promise<void> {
    await this.clientPlansRepository.softDelete({ clientId: id });
    await this.repository.softDelete(id);
  }
  async findById(id: string): Promise<IClient | null> {
    return this.repository.findOneBy({ id });
  }

  async getTotalClients(companyId: string): Promise<number> {
    return this.repository.count({ where: { companyId, isActive: true } });
  }
  async update(client: IClient, data: IUpdateClient): Promise<IClient | null> {
    Object.assign(client, data);
    await this.repository.save(client);

    if (data.planId) {
      await this.clientPlansRepository.update(
        { clientId: client.id },
        { planId: data.planId },
      );
    }

    return client;
  }
}
