/* eslint-disable @typescript-eslint/no-unused-vars */
import { IClient } from '../interfaces/IClient.interface';
import { IClientRepository } from '../interfaces/IClientRepository.interface';
import { Client } from '../models/Client.model';
import { ClientPlans } from '../models/ClientPlans.model';
import { CreateClientData } from '../types/createClient.type';
import { ClientPaymentFilters } from '../types/findClientsFilter.type';
import { FindClientsResponse } from '../types/findClientsResponse.type';
import { IClientPagination } from './Client.repository';

export class InMemoryClientRepository implements IClientRepository {
  findOverdueClients(companyId: string): Promise<Client[]> {
    throw new Error('Method not implemented.');
  }
  getTotalClients(companyId: string): Promise<number> {
    throw new Error('Method not implemented.');
  }
  update(client: IClient, data: Partial<Client>): Promise<IClient | null> {
    throw new Error('Method not implemented.');
  }
  private clients: IClient[] = [];
  async findByCompanyId(companyId: string): Promise<IClientPagination> {
    return Promise.resolve({
      clients: this.clients.filter((client) => client.companyId === companyId),
      totalClients: this.clients.length,
    });
  }
  async create(data: CreateClientData): Promise<IClient> {
    const client = new Client(data);
    this.clients.push(client);
    return Promise.resolve(client);
  }

  async existsByNameAndCompanyId(
    companyId: string,
    name: string,
  ): Promise<boolean> {
    const client = this.clients.find(
      (client) => client.companyId === companyId && client.name === name,
    );
    return !!client;
  }

  async findClients(
    filters: ClientPaymentFilters,
  ): Promise<FindClientsResponse[]> {
    return Promise.resolve([]);
  }

  async findClientPlanByPlanId(planId: string): Promise<ClientPlans[]> {
    return Promise.resolve([]);
  }

  async findClientPlanByClientId(clientId: string): Promise<ClientPlans[]> {
    return Promise.resolve([]);
  }

  async findById(id: string): Promise<IClient | null> {
    const client = this.clients.find((client) => client.id === id);
    return Promise.resolve(client as IClient);
  }
  delete(id: string): Promise<void> {
    this.clients = this.clients.filter((client) => client.id !== id);
    return Promise.resolve();
  }
}
