export type CreateClientPlanData = {
  clientId: string;
  planId: string;
};
