export type CreateClientRequest = {
  name: string;
  phone: string;
  dueDay: number;
  planId: string;
};

export type CreateClientData = {
  name: string;
  phone: string;
  dueDay: number;
  companyId: string;
  planId: string;
  isActive: boolean;
};
