export type ClientPaymentRequest = {
  month: number;
  year: number;
};

export type ClientPaymentFilters = {
  month: number;
  year: number;
  companyId: string;
  clientName?: string;
  dueDay?: string;
  paid?: boolean;
};
