export type FindClientsResponse = {
  id: string;
  name: string;
  phone: string;
  dueDay: number;
  companyId: string;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
  payments: [
    {
      id: string;
      clientId: string;
      month: number;
      year: number;
      paymentDate: Date;
      value: number;
    },
  ];
  paid?: boolean;
};
