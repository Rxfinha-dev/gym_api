/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { IUpdateClient } from '../../interfaces/IClient.interface';
import { UpdateClientUseCase } from './updateClient.useCase';

export class UpdateClientController {
  constructor(private readonly updateClientUseCase: UpdateClientUseCase) {}

  async execute(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    const { clientId } = req.params;
    const data = req.body as IUpdateClient;

    if (!clientId) {
      throw new Error('Id do cliente não informado');
    }

    try {
      await this.updateClientUseCase.execute(String(clientId), data);
      res.json();
    } catch (error: any) {
      next({ message: error.message || 'Erro ao atualizar cliente', error });
    }
  }
}
