import { IPlanRepository } from '../../../plan/interfaces/IPlanRepository.interface';
import { IUpdateClient } from '../../interfaces/IClient.interface';
import { IClientRepository } from '../../interfaces/IClientRepository.interface';

export class UpdateClientUseCase {
  constructor(
    private readonly clientRepository: IClientRepository,
    private readonly planRepository: IPlanRepository,
  ) {}

  async execute(id: string, data: IUpdateClient): Promise<void> {
    const client = await this.clientRepository.findById(id);

    if (!client) {
      throw new Error('Cliente não encontrado');
    }

    const plan = await this.planRepository.findById(data.planId);

    if (!plan) {
      throw new Error('O plano não foi encontrado');
    }

    await this.clientRepository.update(client, data);
  }
}
