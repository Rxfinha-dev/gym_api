/* eslint-disable @typescript-eslint/no-explicit-any */
import { FindClientsAndPaymentsUseCase } from './findClientsAndPayments.useCase';
import { Request, Response, NextFunction } from 'express';

export class FindClientsAndPaymentsController {
  constructor(
    private readonly findClientsAndPaymentsUseCase: FindClientsAndPaymentsUseCase,
  ) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { companyId, month, year, paid, clientName, dueDay } = req.params;
    const query = req.query;

    try {
      const payments = await this.findClientsAndPaymentsUseCase.execute({
        month: month ? Number(month) : Number(query.month),
        year: year ? Number(year) : Number(query.year),
        companyId: companyId ? String(companyId) : String(query.companyId),
        clientName: clientName
          ? String(clientName)
          : query.clientName
            ? String(query.clientName)
            : undefined,
        paid: paid
          ? paid === 'true'
          : query.paid
            ? query.paid === 'true'
            : undefined,
        dueDay: dueDay
          ? String(dueDay)
          : req.query.dueDay
            ? String(req.query.dueDay)
            : undefined,
      });

      return res.json(payments);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao buscar pagamentos', error });
    }
  }
}
