import { IClientRepository } from '../../interfaces/IClientRepository.interface';
import { ClientPaymentFilters } from '../../types/findClientsFilter.type';

export class FindClientsAndPaymentsUseCase {
  constructor(private readonly clientRepository: IClientRepository) {}

  async execute(filters: ClientPaymentFilters) {
    const { month, year, paid } = filters;

    const payments = await this.clientRepository.findClients({
      ...filters,
      month: month || new Date().getMonth() + 1,
      year: year || new Date().getFullYear(),
    });

    if (!payments) {
      throw new Error('Nenhum pagamento encontrado');
    }

    return payments
      .filter((payment) =>
        typeof paid === 'boolean'
          ? Boolean(payment.payments.length) === paid
          : true,
      )
      .map((payment) => ({
        ...payment,
        paid:
          paid ??
          Boolean(
            payment.payments.find((p) => p.month === month && p.year === year),
          ),
      }));
  }
}
