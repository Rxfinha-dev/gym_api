/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Response, Request } from 'express';
import { FindClientByIdUseCase } from './findClientById.useCase';

export class FindClientByIdController {
  constructor(private readonly findClientByIdUseCase: FindClientByIdUseCase) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { id } = req.params;
    try {
      const client = await this.findClientByIdUseCase.execute(id);
      return res.json(client);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao buscar cliente', error });
    }
  }
}
