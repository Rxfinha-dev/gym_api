import { IClient } from '../../interfaces/IClient.interface';
import { IClientRepository } from '../../interfaces/IClientRepository.interface';

export class FindClientByIdUseCase {
  constructor(private readonly clientRepository: IClientRepository) {}

  async execute(id: string): Promise<IClient & { planId: string }> {
    const client = await this.clientRepository.findById(id);

    if (!client) {
      throw new Error('Client não encontrado');
    }

    const clientPlan = await this.clientRepository.findClientPlanByClientId(
      client.id,
    );

    return { ...client, planId: clientPlan[0].planId };
  }
}
