import { NextFunction, Response, Request } from "express";
import { DeleteClientUseCase } from "./deleteClient.useCase";

export class DeleteClientController{
    constructor(private readonly deleteClientUseCase : DeleteClientUseCase) { }

    async execute(
        req : Request,
        res: Response,
        next : NextFunction,
    ): Promise<void> {
        const {id} = req.query;
        try{
            await this.deleteClientUseCase.execute(String(id));
            res.json();

        } catch(error: any){
            next({message: error.message || 'Erro ao deletar cliente',error});
        }
    }
    
}