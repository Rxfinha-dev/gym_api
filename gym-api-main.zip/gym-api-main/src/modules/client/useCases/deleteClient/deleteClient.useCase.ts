import { IPaymentRepository } from '../../../payment/interfaces/IPaymentRepository.interface';
import { IClientRepository } from '../../interfaces/IClientRepository.interface';

export class DeleteClientUseCase {
  constructor(
    private readonly clientRepository: IClientRepository,
    private readonly paymentRepository: IPaymentRepository,
  ) {}

  async execute(id: string): Promise<void> {
    console.log(id);
    const existsClient = await this.clientRepository.findById(id);

    if (!existsClient) {
      throw new Error('O cliente não existe');
    }

    const existClientPayment = await this.paymentRepository.findByClientId(id);

    if (existClientPayment?.length) {
      throw new Error(
        'O cliente não pode ser deletado pois possui vínculo com pagamentos.',
      );
    }

    await this.clientRepository.delete(id);
  }
}
