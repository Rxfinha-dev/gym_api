import { removeMaskFromPhone } from '../../../../helpers/removeMaskFromPhone.helper';
import { FindCompanyByIdUseCase } from '../../../company/useCases/findCompanyById/findCompanyById.useCase';
import { IClientRepository } from '../../interfaces/IClientRepository.interface';
import { CreateClientRequest } from '../../types/createClient.type';

export class CreateClientUseCase {
  constructor(
    private readonly clientRepository: IClientRepository,
    private readonly findCompanyByIdUseCase: FindCompanyByIdUseCase,
  ) {}

  async execute(companyId: string, data: CreateClientRequest) {
    await this.findCompanyByIdUseCase.execute(companyId);

    const alreadyExists = await this.clientRepository.existsByNameAndCompanyId(
      companyId,
      data.name,
    );

    if (alreadyExists) {
      throw new Error(`Cliente '${data.name}' já cadastrado para esta empresa`);
    }

    return this.clientRepository.create({
      name: data.name,
      phone: removeMaskFromPhone(data.phone),
      dueDay: data.dueDay,
      companyId,
      planId: data.planId,
      isActive: true,
    });
  }
}
