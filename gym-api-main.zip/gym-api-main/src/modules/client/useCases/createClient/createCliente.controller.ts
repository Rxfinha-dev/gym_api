/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextFunction, Request, Response } from 'express';
import { CreateClientRequest } from '../../types/createClient.type';
import { CreateClientUseCase } from './createClient.useCase';

export class CreateClientController {
  constructor(private readonly createClientUseCase: CreateClientUseCase) {}

  async execute(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    try {
      const { companyId } = req.params;
      const data = req.body as CreateClientRequest;
      const createdClient = await this.createClientUseCase.execute(
        companyId,
        data,
      );
      res.json(createdClient);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao criar cliente', error });
    }
  }
}
