/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';
import { FindClientsByCompanyUseCase } from './findClientsByCompany.useCase';
import { IClientFilters } from '../../repository/Client.repository';

export class FindClientsByCompanyController {
  constructor(
    private readonly findClientsByCompanyUseCase: FindClientsByCompanyUseCase,
  ) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { companyId } = req.params;
    const { planId, dueDay, isActive, name, phone, page, limit } = req.query;
    try {
      const filters: IClientFilters = {
        companyId,
        planId: planId ? String(planId) : undefined,
        dueDay: dueDay ? Number(dueDay) : undefined,
        isActive: isActive ? Boolean(isActive === 'true') : undefined,
        name: name ? String(name) : undefined,
        phone: phone ? String(phone) : undefined,
        page: page ? Number(page) : undefined,
        limit: limit ? Number(limit) : undefined,
      };

      const clients = await this.findClientsByCompanyUseCase.execute(
        companyId,
        filters,
      );
      return res.json(clients);
    } catch (error: any) {
      next({ message: error.message || 'Erro ao buscar clientes', error });
    }
  }
}
