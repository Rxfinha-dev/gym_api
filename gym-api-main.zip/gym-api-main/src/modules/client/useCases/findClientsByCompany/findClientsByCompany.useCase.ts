import { IClientRepository } from '../../interfaces/IClientRepository.interface';
import { IClientFilters } from '../../repository/Client.repository';

export class FindClientsByCompanyUseCase {
  constructor(private readonly clientRepository: IClientRepository) {}

  async execute(companyId: string, filters: IClientFilters) {
    const clients = await this.clientRepository.findByCompanyId(
      companyId,
      filters,
    );

    if (!clients) {
      throw new Error('Nenhum cliente encontrado para esta empresa');
    }

    return clients;
  }
}
