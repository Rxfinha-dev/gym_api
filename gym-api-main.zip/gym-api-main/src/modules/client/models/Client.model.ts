import { randomUUID } from 'crypto';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Company } from '../../company/models/Company.model';
import { IClient } from '../interfaces/IClient.interface';
import { CreateClientData } from '../types/createClient.type';
import { ClientPlans } from './ClientPlans.model';

@Entity({ name: 'clients' })
export class Client implements IClient {
  @PrimaryColumn()
  id: string;

  @Column()
  name: string;

  @Column()
  phone: string;

  @Column()
  dueDay: number;

  @Column()
  companyId: string;

  @Column({ default: true })
  isActive: boolean;

  @ManyToOne(() => Company, (company) => company.id)
  @JoinColumn({ name: 'companyId', referencedColumnName: 'id' })
  company!: Company;

  @OneToMany(() => ClientPlans, (clientPlans) => clientPlans.client)
  clientPlans!: ClientPlans[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: CreateClientData) {
    this.id = randomUUID();
    this.name = params?.name || '';
    this.phone = params?.phone || '';
    this.dueDay = params?.dueDay || 0;
    this.companyId = params?.companyId || '';
    this.isActive = true;
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
