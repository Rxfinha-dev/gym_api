import { randomUUID } from 'crypto';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Plans } from '../../plan/models/Plan.model';
import { IClientPlan } from '../interfaces/IClientPlan.interface';
import { CreateClientPlanData } from '../types/createClientPlan.type';
import { Client } from './Client.model';

@Entity({ name: 'client_plans' })
export class ClientPlans implements IClientPlan {
  @PrimaryColumn()
  id: string;

  @Column()
  clientId: string;

  @ManyToOne(() => Client, (client) => client.clientPlans)
  @JoinColumn({ name: 'clientId', referencedColumnName: 'id' })
  client!: Client;

  @Column()
  planId: string;

  @ManyToOne(() => Plans, (plans) => plans.clientPlans)
  @JoinColumn({ name: 'planId', referencedColumnName: 'id' })
  plans!: Plans;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date | null;

  constructor(params?: CreateClientPlanData) {
    this.id = randomUUID();
    this.clientId = params?.clientId || '';
    this.planId = params?.planId || '';
    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.deletedAt = null;
  }
}
