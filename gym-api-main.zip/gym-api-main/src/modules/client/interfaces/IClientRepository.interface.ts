import { Client } from '../models/Client.model';
import { ClientPlans } from '../models/ClientPlans.model';
import {
  IClientFilters,
  IClientPagination,
} from '../repository/Client.repository';
import { CreateClientData } from '../types/createClient.type';
import { ClientPaymentFilters } from '../types/findClientsFilter.type';
import { FindClientsResponse } from '../types/findClientsResponse.type';
import { IClient } from './IClient.interface';

export interface IClientRepository {
  findByCompanyId(
    companyId: string,
    filters: IClientFilters,
  ): Promise<IClientPagination>;
  create(data: CreateClientData): Promise<IClient>;
  existsByNameAndCompanyId(companyId: string, name: string): Promise<boolean>;
  findClients(filters: ClientPaymentFilters): Promise<FindClientsResponse[]>;
  findClientPlanByPlanId(planId: string): Promise<ClientPlans[]>;
  findClientPlanByClientId(clientId: string): Promise<ClientPlans[]>;
  findOverdueClients(companyId: string): Promise<Client[]>;
  findById(id: string): Promise<IClient | null>;
  delete(id: string): Promise<void>;
  getTotalClients(companyId: string): Promise<number>;
  update(client: IClient, data: Partial<Client>): Promise<IClient | null>;
}
