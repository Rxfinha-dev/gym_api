export interface IClient {
  id: string;
  name: string;
  phone: string;
  dueDay: number;
  companyId: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}

export interface IUpdateClient extends Partial<IClient> {
  planId: string;
}
