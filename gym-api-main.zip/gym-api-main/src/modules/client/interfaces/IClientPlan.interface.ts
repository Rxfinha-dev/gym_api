export interface IClientPlan {
  id: string;
  clientId: string;
  planId: string;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}
