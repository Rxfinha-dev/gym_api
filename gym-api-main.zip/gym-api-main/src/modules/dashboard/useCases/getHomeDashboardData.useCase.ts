import { IClientRepository } from '../../client/interfaces/IClientRepository.interface';
import { IPaymentRepository } from '../../payment/interfaces/IPaymentRepository.interface';

export interface IDashboardData {
  totalClients: number;
  clientsPaidThisMonth: number;
  clientsNotPaidThisMonth: number;
}

export class GetHomeDashboardDataUseCase {
  constructor(
    private readonly clientRepository: IClientRepository,
    private readonly paymentRepository: IPaymentRepository,
  ) {}

  async execute(companyId: string): Promise<IDashboardData> {
    const totalClients = await this.clientRepository.getTotalClients(companyId);

    const { clientsPaidThisMonth, clientsNotPaidThisMonth } =
      await this.paymentRepository.getNumberOfPaymentsAndOverduesByCompanyId(
        companyId,
      );

    return { totalClients, clientsPaidThisMonth, clientsNotPaidThisMonth };
  }
}
