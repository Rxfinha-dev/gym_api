/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response, NextFunction } from 'express';
import { GetHomeDashboardDataUseCase } from './getHomeDashboardData.useCase';

export class GetHomeDashboardDataController {
  constructor(
    private readonly getHomeDashboardDataUseCase: GetHomeDashboardDataUseCase,
  ) {}

  async execute(req: Request, res: Response, next: NextFunction) {
    const { companyId } = req.params;

    try {
      const data = await this.getHomeDashboardDataUseCase.execute(companyId);
      return res.json(data);
    } catch (error: any) {
      next({
        message: error.message || 'Erro ao buscar dados do dashboard',
        error,
      });
    }
  }
}
