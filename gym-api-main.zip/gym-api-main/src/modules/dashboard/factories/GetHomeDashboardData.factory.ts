import { IClientRepository } from '../../client/interfaces/IClientRepository.interface';
import { ClientRepository } from '../../client/repository/Client.repository';
import { IPaymentRepository } from '../../payment/interfaces/IPaymentRepository.interface';
import { PaymentRepository } from '../../payment/repositories/Payment.repository';
import { GetHomeDashboardDataController } from '../useCases/getHomeDashboardData.controller';
import { GetHomeDashboardDataUseCase } from '../useCases/getHomeDashboardData.useCase';

export function makeGetHomeDashboardData(
  clientRepo?: IClientRepository,
  paymentRepo?: IPaymentRepository,
) {
  const clientRepository = clientRepo ? clientRepo : new ClientRepository();
  const paymentRepository = paymentRepo ? paymentRepo : new PaymentRepository();
  const getHomeDashboardDataUseCase = new GetHomeDashboardDataUseCase(
    clientRepository,
    paymentRepository,
  );
  return new GetHomeDashboardDataController(getHomeDashboardDataUseCase);
}
