/* eslint-disable no-process-exit */
import { app } from './app';
import { AppDataSource } from './config/typeorm.config';
const PORT = process.env.PORT || 3000;

AppDataSource.initialize()
  .then(() => {
    console.log('Conexão com o banco de dados estabelecida');

    app.listen(PORT, () => {
      console.log(`Servidor rodando na porta ${PORT}`);
    });

    // Gracefully close sessions on application shutdown or process termination
    process.on('SIGINT', async () => {
      console.log('sigint');
      // const whatsappService = new WhatsAppServiceV2();
      // await whatsappService.closeAllSessions();
      process.exit();
    });

    process.on('SIGTERM', async () => {
      console.log('sigterm');
      // const whatsappService = new WhatsAppServiceV2();
      // await whatsappService.closeAllSessions();
      process.exit();
    });
  })
  .catch((error) => {
    console.error('Erro ao conectar com o banco de dados', error);
  });
