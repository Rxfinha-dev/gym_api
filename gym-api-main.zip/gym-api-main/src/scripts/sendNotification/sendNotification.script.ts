/* eslint-disable no-process-exit */
import dotenv from 'dotenv';
import { AppDataSource } from '../../config/typeorm.config';
import { makeSendNotificationUseCase } from '../../modules/notifications/factories/SendNotificationUseCase.factory';

dotenv.config();

function sendNotification() {
  console.log(
    'Iniciando execução do SCRIPT de notificações...',
    process.env.DB_HOST,
  );

  AppDataSource.initialize()
    .then(async () => {
      console.log('Conexão com o banco de dados estabelecida');
      await (await makeSendNotificationUseCase()).execute();
    })
    .catch((error) => {
      console.log(error);
    })
    .finally(() => {
      process.exit();
    });
}

sendNotification();
